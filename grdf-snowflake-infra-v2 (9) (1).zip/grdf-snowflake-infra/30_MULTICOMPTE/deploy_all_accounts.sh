#!/bin/bash
# =================================================================
# deploy_all_accounts.sh — Déploiement multi-comptes GRDF
#
# USAGE :
#   ./30_MULTICOMPTE/deploy_all_accounts.sh [MODE] [COMPTE]
#
# MODES :
#   update   (défaut) Recharge uniquement les procédures 10_PROCEDURES/
#                     Safe à lancer à tout moment — CREATE OR REPLACE
#   init             Premier déploiement : 00_INIT/ + 10_PROCEDURES/
#   procs            Procédures uniquement (= update)
#   all              init + procs (identique à init)
#
# COMPTE (optionnel) :
#   Si fourni, déploie uniquement sur ce compte.
#   Sinon, déploie sur tous les comptes actifs dans accounts.conf.
#
# EXEMPLES :
#   ./deploy_all_accounts.sh update               # MAJ procédures tous comptes
#   ./deploy_all_accounts.sh init compte_drc      # Premier déploiement DRC seul
#   ./deploy_all_accounts.sh init                 # Premier déploiement tous comptes
#
# PRÉREQUIS :
#   - SnowSQL CLI installé
#   - ~/.snowsql/config avec les connexions
#   - Exécuter depuis la RACINE du projet
# =================================================================

set -euo pipefail

# ── Chemins ────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
CONFIG_FILE="$SCRIPT_DIR/accounts.conf"
LOG_DIR="$SCRIPT_DIR/logs"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
OVERALL_LOG="$LOG_DIR/${TIMESTAMP}_deploy.log"

mkdir -p "$LOG_DIR"

# ── Paramètres ─────────────────────────────────────────────────
MODE="${1:-update}"
TARGET_ACCOUNT="${2:-}"  # Vide = tous les comptes actifs

# ── Ordre des fichiers ─────────────────────────────────────────
INIT_FILES=(
    "00_INIT/01_admin_database.sql"
    "00_INIT/02_tags_securite.sql"
    "00_INIT/03_meta_registry.sql"
    "00_INIT/04_audit_views.sql"
)

PROC_FILES=(
    "10_PROCEDURES/SP_LOG_EVENT.sql"
    "10_PROCEDURES/SP_BUILD_NAMES.sql"
    "10_PROCEDURES/SP_GRANTS.sql"
    "10_PROCEDURES/SP_TAGS.sql"
    "10_PROCEDURES/SP_ROLES.sql"
    "10_PROCEDURES/SP_ROLES_ADVANCED.sql"
    "10_PROCEDURES/SP_OBJECTS.sql"
    "10_PROCEDURES/SP_ORCHESTRATORS.sql"
    "10_PROCEDURES/SP_USERS.sql"
    "10_PROCEDURES/SP_STORAGE.sql"
    "10_PROCEDURES/SP_LIFECYCLE.sql"
)

# ── Fonctions ──────────────────────────────────────────────────
log() { echo "[$(date +"%H:%M:%S")] $1" | tee -a "$OVERALL_LOG"; }
ok()  { log "  ✅ $1"; }
err() { log "  ❌ $1"; }
sep() { log "───────────────────────────────────────────"; }

deploy_file() {
    local account="$1" file="$2"
    local name; name=$(basename "$file" .sql)
    local file_log="$LOG_DIR/${TIMESTAMP}_${account}_${name}.log"
    
    log "     $file"
    
    if snowsql -c "$account" \
               -f "$PROJECT_ROOT/$file" \
               --stop-on-error \
               -o output_file="$file_log" \
               -o friendly=false \
               -o timing=true \
               2>>"$OVERALL_LOG"; then
        ok "$name"
        return 0
    else
        err "$name — voir $file_log"
        return 1
    fi
}

deploy_account() {
    local account="$1" description="$2"
    local errors=0
    
    sep
    log "COMPTE : $account — $description"
    sep

    if [[ "$MODE" == "init" || "$MODE" == "all" ]]; then
        log "  [1/2] Initialisation (00_INIT) ..."
        for file in "${INIT_FILES[@]}"; do
            deploy_file "$account" "$file" || ((errors++))
        done
    fi

    log "  [2/2] Procédures (10_PROCEDURES) ..."
    for file in "${PROC_FILES[@]}"; do
        deploy_file "$account" "$file" || ((errors++))
    done

    if [[ $errors -eq 0 ]]; then
        ok "COMPTE $account : SUCCÈS"
    else
        err "COMPTE $account : $errors fichier(s) en erreur"
    fi

    return $errors
}

# ── Main ───────────────────────────────────────────────────────
TOTAL_ERRORS=0
ACCOUNTS_DEPLOYED=0

log "═══════════════════════════════════════════"
log "  GRDF Snowflake Framework — Multi-comptes"
log "  Mode    : $MODE"
log "  Config  : $CONFIG_FILE"
log "  Log     : $OVERALL_LOG"
log "═══════════════════════════════════════════"

# Lire accounts.conf (ignorer commentaires et lignes vides)
while IFS='|' read -r conn desc envs actif; do
    [[ "$conn" =~ ^#.*$ || -z "$conn" ]] && continue  # commentaires et vides
    
    actif="${actif// /}"  # trim espaces
    
    # Filtrer par compte cible si fourni
    if [[ -n "$TARGET_ACCOUNT" && "$conn" != "$TARGET_ACCOUNT" ]]; then
        continue
    fi
    
    # Ignorer les comptes inactifs (sauf si compte cible explicite)
    if [[ "$actif" != "true" && -z "$TARGET_ACCOUNT" ]]; then
        log "SKIP (inactif) : $conn — $desc"
        continue
    fi
    
    deploy_account "$conn" "$desc" || ((TOTAL_ERRORS++))
    ((ACCOUNTS_DEPLOYED++))
done < "$CONFIG_FILE"

sep
if [[ $ACCOUNTS_DEPLOYED -eq 0 ]]; then
    log "⚠️  Aucun compte déployé — vérifier accounts.conf ou le nom de compte fourni"
elif [[ $TOTAL_ERRORS -eq 0 ]]; then
    log "✅ DÉPLOIEMENT TERMINÉ — $ACCOUNTS_DEPLOYED compte(s) mis à jour"
else
    log "❌ DÉPLOIEMENT TERMINÉ AVEC ERREURS — $TOTAL_ERRORS compte(s) en erreur sur $ACCOUNTS_DEPLOYED"
    log "   Consulter les logs dans $LOG_DIR"
fi
sep

exit $TOTAL_ERRORS
