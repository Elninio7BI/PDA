# Déploiement multi-comptes GRDF

## Principe

Le déploiement multi-comptes repose sur **SnowSQL CLI** qui exécute
les fichiers SQL dans l'ordre sur chaque compte Snowflake.

Il n'y a qu'un seul fichier à configurer : `accounts.conf`.
Le script `deploy_all_accounts.sh` ne se touche jamais.

## Configuration

### 1. Configurer SnowSQL (~/.snowsql/config)

```ini
[connections.compte_drc]
account  = grdf-drc.eu-west-1.privatelink
username = ADMIN_DEPLOY
private_key_path = ~/.ssh/snowflake_key.p8

[connections.compte_asd]
account  = grdf-asd.eu-west-1.privatelink
username = ADMIN_DEPLOY
private_key_path = ~/.ssh/snowflake_key.p8
```

### 2. Activer/désactiver des comptes (accounts.conf)

```
compte_drc|Compte DRC|C1,H1,P1|true    ← actif
compte_nouveau|Compte X|C1|false        ← ignoré
```

Pour ajouter un compte : ajouter une ligne, passer `true`.
Pour retirer un compte : passer `false` (ne jamais supprimer la ligne).

## Usage

```bash
# Exécuter depuis la RACINE du projet, pas depuis 30_MULTICOMPTE/

# Mise à jour procédures sur tous les comptes actifs (safe, rejoutable)
./30_MULTICOMPTE/deploy_all_accounts.sh update

# Premier déploiement complet sur tous les comptes
./30_MULTICOMPTE/deploy_all_accounts.sh init

# Premier déploiement sur un seul compte
./30_MULTICOMPTE/deploy_all_accounts.sh init compte_drc

# Mise à jour d'un seul compte
./30_MULTICOMPTE/deploy_all_accounts.sh update compte_asd
```

## Logs

Chaque exécution génère des logs horodatés dans `30_MULTICOMPTE/logs/` :
- `2025-02-25_10-30-00_deploy.log` : log global
- `2025-02-25_10-30-00_compte_drc_SP_ROLES.log` : détail par fichier

## Flux de déploiement recommandé (GitLab CI/CD)

```yaml
deploy-framework:
  stage: deploy
  script:
    - ./30_MULTICOMPTE/deploy_all_accounts.sh update
  only:
    - main
  when: manual
```
