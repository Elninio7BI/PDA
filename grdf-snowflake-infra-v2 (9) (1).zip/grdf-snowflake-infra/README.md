# GRDF — Snowflake Infrastructure Framework

Framework de déploiement du socle Snowflake GRDF.
Architecture 3 niveaux de délégation, tags de sécurité DCP, grants exhaustifs.

---

## Structure du projet

```
grdf-snowflake-infra/
│
├── 00_INIT/          ← Une seule fois, avec ACCOUNTADMIN
│   ├── 01_admin_database.sql   Base BD_ADMIN_INFRA + schemas + log
│   ├── 02_tags_securite.sql    6 tags + Masking Policies + RAP DCP
│   └── 03_meta_registry.sql    Tables de traçabilité des objets
│
├── 10_PROCEDURES/    ← Recharger à chaque évolution du framework
│   ├── SP_LOG_EVENT.sql        Logging centralisé
│   ├── SP_BUILD_NAMES.sql      Calcul des identifiants (nommage)
│   ├── SP_GRANTS.sql           Grants RO / RW / FULL (12 types d'objets)
│   ├── SP_TAGS.sql             Application des tags sur les objets
│   ├── SP_ROLES.sql            Création des rôles (3 niveaux)
│   ├── SP_OBJECTS.sql          Création DB / WH / Resource Monitors / Table
│   └── SP_ORCHESTRATORS.sql   Points d'entrée pour les équipes
│
└── 20_DEPLOY/        ← Un fichier par socle déployé
    └── BRZ_DRC_QEO_C1.sql     Exemple : Bronze DRC QEO env C1
```

---

## Ordre d'exécution

### Étape 1 — Init (une seule fois par compte Snowflake)

```
Rôle requis : ACCOUNTADMIN
```

Exécuter dans cet ordre :
1. `00_INIT/01_admin_database.sql`
2. `00_INIT/02_tags_securite.sql`
3. `00_INIT/03_meta_registry.sql`

### Étape 2 — Procédures (à chaque mise à jour du framework)

```
Rôle requis : ACCOUNTADMIN (pour compiler les procédures)
```

Exécuter dans cet ordre :
1. `10_PROCEDURES/SP_LOG_EVENT.sql`
2. `10_PROCEDURES/SP_BUILD_NAMES.sql`
3. `10_PROCEDURES/SP_GRANTS.sql`
4. `10_PROCEDURES/SP_TAGS.sql`
5. `10_PROCEDURES/SP_ROLES.sql`
6. `10_PROCEDURES/SP_OBJECTS.sql`
7. `10_PROCEDURES/SP_ORCHESTRATORS.sql`

Toutes ces procédures sont `CREATE OR REPLACE` — rejouables sans risque.

### Étape 3 — Déploiement d'un socle (équipe projet)

```
Rôle requis : ACCOUNTADMIN (délègue en interne via RD_* et RD_DB_*)
```

Copier `20_DEPLOY/BRZ_DRC_QEO_C1.sql`, adapter les paramètres, exécuter.

---

## Convention de nommage

| Variable               | Exemple     | Description                        |
|------------------------|-------------|------------------------------------|
| `FM_DBTYPE`            | `BRZ`       | Couche ou stream (BRZ, DRC, GLD…) |
| `FM_SHTYPE`            | `DRC`       | Domaine ou couche dans le schéma   |
| `FM_OFFRE`             | `OE`        | Type d'offre (OE, OM, BIE, IALAB…)|
| `FM_APP`               | `QEO`       | Application (NULL = schéma générique) |
| `FM_ENV`               | `C1`        | Environnement (C1-C9, H1-H9, P1-P9)|

**Objets générés :**

| Objet            | Pattern                                     | Exemple                          |
|------------------|---------------------------------------------|----------------------------------|
| Database         | `BD_{DBTYPE}_{ENV}`                         | `BD_BRZ_C1`                      |
| WH Database      | `WH_{DBTYPE}_{SIZE}_{ENV}`                  | `WH_BRZ_XS_C1`                   |
| WH Applicatif    | `WH_{DBTYPE}_{SHTYPE}_{OFFRE}[_{APP}]_{SIZE}_{ENV}` | `WH_BRZ_DRC_OE_QEO_XS_C1` |
| Schema           | `SH_{SHTYPE}_{OFFRE}[_{APP}]`               | `SH_DRC_OE_QEO`                  |
| Table            | `TB_{OFFRE}_{NOM}`                          | `TB_OE_POINT_PCE`                |
| Vue classique    | `VL_{OFFRE}_{NOM}`                          | `VL_OE_POINT_PCE`                |
| Vue sécurisée    | `VS_{OFFRE}_{NOM}`                          | `VS_OE_POINT_PCE`                |
| Vue matérialisée | `VP_{OFFRE}_{NOM}`                          | `VP_OE_POINT_PCE`                |

**Rôles générés :**

| Famille  | Pattern                                          | Niveau     |
|----------|--------------------------------------------------|------------|
| `RD_*`   | `RD_{DBTYPE}_{SHTYPE}_[SYSADMIN\|SECADMIN\|USRADMIN\|ACCADMIN]_{ENV}` | Compte |
| `RD_DB_*`| `RD_DB_{DBTYPE}_{ENV}_[SYSADMIN\|SECADMIN\|USRADMIN]` | Database |
| `RS_*`   | `RS_{DBTYPE}_{SHTYPE}_{OFFRE}[_{APP}]_{ENV}_[OWNER\|ADMIN\|TEAM]` | Schéma |
| `RA_*`   | `RA_{DBTYPE}_{SHTYPE}[_{APP}]_[OWNER\|RW\|RO]_{ENV}` | Données |
| `RF_*`   | `RF_{DBTYPE}_{SHTYPE}[_{APP}]_[ADMIN\|MOE\|ANALYST\|TASK]_{ENV}` | Fonctionnel |

---

## Modèle de délégation

```
ACCOUNTADMIN
  └── RD_{DBTYPE}_{SHTYPE}_SYSADMIN_{ENV}   ← Créé par ACCOUNTADMIN
        └── RD_DB_{DBTYPE}_{ENV}_SYSADMIN   ← Créé par RD_*
              └── RS_*_OWNER                ← Créé par RD_DB_*
                    └── TB_*, VL_*, VS_*    ← Créé par RS_*_OWNER
```

Conséquence : une équipe projet reçoit `RS_*_OWNER` et est totalement autonome
pour créer ses tables/vues **sans jamais avoir besoin d'un admin**.

---

## Sécurité par tags

Poser un tag = activer la protection automatiquement.

```sql
-- Taguer une colonne email comme DCP sensible
-- → Tous les utilisateurs sans RF_DCP_AUTHORIZED voient '***DCP_SENSIBLE***'
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_APPLY_COLUMN_TAG(
    'BD_BRZ_C1.SH_DRC_OE_QEO.TB_OE_POINT_PCE',
    'EMAIL_CONTACT', 'sensible', 'C3'
);

-- Donner accès DCP à un utilisateur
GRANT ROLE RF_DCP_AUTHORIZED TO USER jean_dupont;
```

| Tag              | Valeurs         | Protection activée          |
|------------------|-----------------|-----------------------------|
| `dcp='sensible'` | normal/sensible | Masking auto sur la colonne |
| `confidentialite`| C1/C2/C3/C4     | Masking C3/C4 sur la colonne|
| `application`    | libre           | Classification / audit      |
| `environnement`  | c1…p3           | Classification / audit      |
| `domaine`        | libre           | Classification / audit      |
| `couche`         | BRZ/SLV/GLD…   | Classification / audit      |

---

## Ajouter un nouveau socle

1. Copier `20_DEPLOY/BRZ_DRC_QEO_C1.sql`
2. Modifier les 5 variables en haut du fichier
3. Exécuter — c'est tout

```sql
SET FM_DBTYPE = 'DRC';
SET FM_SHTYPE = 'SLV';
SET FM_OFFRE  = 'OM';
SET FM_APP    = 'PRESTA';
SET FM_ENV    = 'C1';
```

---

## Prérequis

- Snowflake Enterprise (tags + masking policies)
- Rôle ACCOUNTADMIN pour l'init et la compilation des procédures
- `USE SECONDARY ROLES ALL` actif lors des déploiements
