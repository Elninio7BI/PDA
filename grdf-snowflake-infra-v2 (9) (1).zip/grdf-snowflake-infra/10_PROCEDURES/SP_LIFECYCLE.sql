/* =================================================================
   SP_LIFECYCLE.sql - Cycle de vie : Replication, Nettoyage, Multi-comptes
   
   SP_REPLICATE_ENV      -> Dupliquer un environnement (C1->H1, C1->P1)
   SP_DROP_SCHEMA_FULL   -> Supprimer proprement un schema + ses roles
   SP_DROP_DATABASE_FULL -> Supprimer une database + tous ses objets
   SP_DROP_DOMAIN        -> Supprimer tout un domaine (schemas + roles + WH)
   SP_RESET_AND_REDEPLOY -> Nettoyer et recreer (utile en dev/test)
   
   --- REPLICATION CROSS-ACCOUNT ------------------------------
   La replication Snowflake native (ALTER DATABASE ENABLE REPLICATION)
   permet de repliquer les donnees.
   
   Pour repliquer le FRAMEWORK (procedures + structure) sur un autre
   compte, c'est different : il faut re-executer les fichiers SQL.
   SP_REPLICATE_ENV gere la duplication d'un environnement GRDF :
   creer H1 avec les memes schemas/roles que C1, mais vide de donnees.
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_REPLICATE_ENV(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,NUMBER,NUMBER,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_SCHEMA_FULL(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_DATABASE_FULL(VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_RESET_AND_REDEPLOY(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);


/* -- SP_REPLICATE_ENV ------------------------------------------
   Duplique la STRUCTURE (pas les donnees) d'un environnement vers
   un autre. Cree les memes schemas, roles et warehouses.
   
   Cas typique : GRDF deploie en C1, veut creer H1 identique.
   
   P_DBTYPE        : couche (BRZ, DRC...)
   P_SHTYPE        : domaine
   P_ENV_SOURCE    : environnement source (ex: C1)
   P_ENV_TARGET    : environnement cible (ex: H1, P1)
   P_USER          : utilisateur recevant les roles dans le nouvel env
   P_QUOTA_PROD    : quota RM pour l'env cible
   P_QUOTA_HP      : quota RM HP pour l'env cible
   
   ROLE REQUIS : ACCOUNTADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_REPLICATE_ENV(
    P_DBTYPE     VARCHAR,
    P_SHTYPE     VARCHAR,
    P_ENV_SOURCE VARCHAR,
    P_ENV_TARGET VARCHAR,
    P_USER       VARCHAR,
    P_WH_SIZE    VARCHAR DEFAULT 'XS',
    P_QUOTA_PROD NUMBER  DEFAULT 200,
    P_QUOTA_HP   NUMBER  DEFAULT 50,
    P_NOTIFY     VARCHAR DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_cnt_schemas NUMBER;
    v_query_id    VARCHAR;
    v_replicated  NUMBER := 0;
    v_t           TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT(
        'SP_REPLICATE_ENV','INFO',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV_TARGET,
        'DATABASE','START',
        'Replication structure ' || :P_ENV_SOURCE || ' -> ' || :P_ENV_TARGET, NULL, NULL);

    -- Etape 1 : Deployer le Tier 1 (database + roles delegues) sur l'env cible
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_DATABASE(
        :P_DBTYPE, :P_SHTYPE, :P_ENV_TARGET, :P_USER, :P_QUOTA_PROD, :P_NOTIFY);

    -- Etape 2 : Recuperer tous les schemas deployes dans l'env source
    SELECT COUNT(*) INTO v_cnt_schemas
    FROM BD_ADMIN_INFRA.META.TB_SCHEMAS
    WHERE DBTYPE = :P_DBTYPE AND SHTYPE = :P_SHTYPE AND ENV = :P_ENV_SOURCE;

    IF (v_cnt_schemas = 0) THEN
        RETURN 'WARN: Aucun schema trouve pour ' || :P_DBTYPE || '_' || :P_SHTYPE || '_' || :P_ENV_SOURCE;
    END IF;

    -- Etape 3 : Pour chaque schema source, deployer le Tier 2 sur l'env cible
    LET c_schemas CURSOR FOR (
        SELECT SHTYPE, OFFRE, APP, ENV
        FROM BD_ADMIN_INFRA.META.TB_SCHEMAS
        WHERE DBTYPE = :P_DBTYPE AND SHTYPE = :P_SHTYPE AND ENV = :P_ENV_SOURCE
    );
    OPEN c_schemas;
    FOR rec IN c_schemas DO
        CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_SCHEMA(
            :P_DBTYPE, rec.SHTYPE, rec.OFFRE, rec.APP, :P_ENV_TARGET,
            :P_USER, :P_WH_SIZE, :P_QUOTA_PROD, :P_QUOTA_HP, :P_NOTIFY, NULL);
        v_replicated := v_replicated + 1;
    END FOR;
    CLOSE c_schemas;

    -- Note : les tables ne sont PAS repliquees (structure seulement)
    -- Pour repliquer les donnees -> utiliser Snowflake Replication native
    -- ou un pipeline dbt

    v_r := 'REPLICATED: ' || :P_ENV_SOURCE || ' -> ' || :P_ENV_TARGET
            || ' - ' || v_replicated || ' schema(s) deploye(s) (structure seule, sans donnees)';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT(
        'SP_REPLICATE_ENV','SUCCESS',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV_TARGET,
        'DATABASE','COMPLETE', v_r,
        DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),
        DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION
    WHEN OTHER THEN
        v_sqlstate := SQLSTATE;
        v_sqlerrm  := SQLERRM;
        CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_REPLICATE_ENV','ERROR',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV_TARGET,'DATABASE','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;


/* -- SP_DROP_SCHEMA_FULL ---------------------------------------
   Supprime proprement un schema + ses roles RS_*, RA_*, RF_*
   et son warehouse applicatif.
   Ne supprime PAS la database ni les roles RD_* et RD_DB_*.
   
   CORRECTION : le pattern FLATTEN+SHOW imbrique n'est pas supporte.
   On utilise 3 blocs SHOW separes avec une variable intermediaire
   pour eviter le cast ::VARCHAR sur une expression dotee (v_pat.VALUE).
   
   ROLE REQUIS : RD_DB_*_SYSADMIN + RD_DB_*_USRADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DROP_SCHEMA_FULL(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP VARCHAR, P_ENV VARCHAR,
    P_CONFIRM VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_n         VARIANT;
    v_db        VARCHAR;
    v_sch       VARCHAR;
    v_wh_app    VARCHAR;
    v_rm_prod   VARCHAR;
    v_rm_hp     VARCHAR;
    v_db_sys    VARCHAR;
    v_db_usr    VARCHAR;
    v_query_id  VARCHAR;
    v_dropped   NUMBER := 0;
    v_pattern   VARCHAR;  -- variable intermediaire pour SHOW LIKE (pas de cast inline)
    v_t         TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    IF (:P_CONFIRM != 'DROP_CONFIRMED') THEN
        RETURN 'ABORTED: passer P_CONFIRM=''DROP_CONFIRMED'' pour confirmer';
    END IF;

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV) INTO v_n;
    v_db      := v_n:DB::VARCHAR;
    v_sch     := v_n:FULL_SCHEMA::VARCHAR;
    v_wh_app  := v_n:WH_APP::VARCHAR;
    v_rm_prod := v_n:RM_PROD::VARCHAR;
    v_rm_hp   := v_n:RM_HP::VARCHAR;
    v_db_sys  := v_n:RD_BD_SYSADMIN::VARCHAR;
    v_db_usr  := v_n:RD_BD_USRADMIN::VARCHAR;

    -- 1. Supprimer le schema (cascade les tables, vues, streams...)
    EXECUTE IMMEDIATE 'USE ROLE ' || v_db_sys;
    EXECUTE IMMEDIATE 'DROP SCHEMA IF EXISTS ' || v_sch;

    -- 2. Supprimer le warehouse applicatif
    EXECUTE IMMEDIATE 'DROP WAREHOUSE IF EXISTS ' || v_wh_app;

    -- 3. Supprimer les Resource Monitors (ACCOUNTADMIN requis)
    BEGIN
        EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
        EXECUTE IMMEDIATE 'DROP RESOURCE MONITOR IF EXISTS ' || v_rm_prod;
        EXECUTE IMMEDIATE 'DROP RESOURCE MONITOR IF EXISTS ' || v_rm_hp;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    -- 4. Supprimer les roles - 3 blocs SHOW separes
    -- (FLATTEN+FOR+SHOW imbrique non supporte ; cast ::VARCHAR sur expression dotee interdit)
    EXECUTE IMMEDIATE 'USE ROLE ' || v_db_usr;

    -- Bloc RS_* (admin schema)
    v_pattern := 'RS_%_' || :P_SHTYPE || '_%_' || :P_OFFRE || '%_' || :P_ENV || '%';
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped := v_dropped + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- Bloc RA_* (acces donnees)
    v_pattern := 'RA_%_SH_' || :P_SHTYPE || '%' || COALESCE(:P_APP,'') || '_%_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped := v_dropped + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- Bloc RF_* (profils fonctionnels)
    v_pattern := 'RF_%_SH_' || :P_SHTYPE || '%' || COALESCE(:P_APP,'') || '_%_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped := v_dropped + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- 5. Nettoyer le registre META
    DELETE FROM BD_ADMIN_INFRA.META.TB_SCHEMAS    WHERE FULL_SCHEMA = v_sch;
    DELETE FROM BD_ADMIN_INFRA.META.TB_WAREHOUSES WHERE WH_NAME = v_wh_app;

    v_r := 'DROPPED: ' || v_sch || ' + WH + ' || v_dropped || ' role(s)';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DROP_SCHEMA_FULL','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION
    WHEN OTHER THEN
        v_sqlstate := SQLSTATE;
        v_sqlerrm  := SQLERRM;
        CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DROP_SCHEMA_FULL','ERROR',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;


/* -- SP_DROP_DATABASE_FULL -------------------------------------
   Supprime une database entiere + TOUS ses schemas + roles + WH.
   Supprime aussi les roles RD_DB_* et RD_* du domaine.
   OPERATION DESTRUCTIVE - ne pas utiliser en prod sans sauvegarde.
   
   ROLE REQUIS : ACCOUNTADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DROP_DATABASE_FULL(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_ENV VARCHAR,
    P_CONFIRM VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_n             VARIANT;
    v_db            VARCHAR;
    v_wh_db         VARCHAR;
    v_query_id      VARCHAR;
    v_dropped_roles NUMBER := 0;
    v_pattern       VARCHAR;  -- variable intermediaire pour SHOW LIKE
    v_t             TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    IF (:P_CONFIRM != 'DROP_CONFIRMED') THEN
        RETURN 'ABORTED: passer P_CONFIRM=''DROP_CONFIRMED'' pour confirmer. OPERATION IRREVERSIBLE.';
    END IF;

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE, :P_SHTYPE, 'X', 'X', :P_ENV) INTO v_n;
    v_db    := v_n:DB::VARCHAR;
    v_wh_db := v_n:WH_DB::VARCHAR;

    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';

    -- 1. Supprimer la database (cascade toute la structure interne)
    EXECUTE IMMEDIATE 'DROP DATABASE IF EXISTS ' || v_db;

    -- 2. Supprimer le WH niveau DB
    EXECUTE IMMEDIATE 'DROP WAREHOUSE IF EXISTS ' || v_wh_db;

    -- 3. Supprimer le RM niveau DB
    BEGIN
        EXECUTE IMMEDIATE 'DROP RESOURCE MONITOR IF EXISTS ' || v_n:RM_DB::VARCHAR;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    -- 4. Supprimer TOUS les roles lies a cet env - 5 blocs SHOW separes
    -- (FLATTEN+FOR+SHOW imbrique non supporte ; cast ::VARCHAR sur expression dotee interdit)

    -- RD_* (roles delegues domaine)
    v_pattern := 'RD_%_' || :P_SHTYPE || '_%_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped_roles := v_dropped_roles + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- RD_DB_* (admins database)
    v_pattern := 'RD_DB_' || :P_DBTYPE || '_' || :P_ENV || '_%';
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped_roles := v_dropped_roles + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- RA_* (acces donnees)
    v_pattern := 'RA_%_SH_' || :P_SHTYPE || '_%_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped_roles := v_dropped_roles + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- RF_* (profils fonctionnels)
    v_pattern := 'RF_%_SH_' || :P_SHTYPE || '_%_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped_roles := v_dropped_roles + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- RS_* (admin schema - ancienne nomenclature, conserve pour compat)
    v_pattern := 'RS_%_' || :P_SHTYPE || '_%_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped_roles := v_dropped_roles + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- RF_{DBTYPE}_DOM_* (profils domaine transverses)
    v_pattern := 'RF_%_DOM_' || :P_SHTYPE || '_%_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;
    FOR rec IN (SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))) DO
        BEGIN
            EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || rec.RNAME;
            v_dropped_roles := v_dropped_roles + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;

    -- 5. Nettoyer META
    DELETE FROM BD_ADMIN_INFRA.META.TB_DATABASES  WHERE DBTYPE = :P_DBTYPE AND ENV = :P_ENV;
    DELETE FROM BD_ADMIN_INFRA.META.TB_WAREHOUSES WHERE DBTYPE = :P_DBTYPE AND ENV = :P_ENV;
    DELETE FROM BD_ADMIN_INFRA.META.TB_SCHEMAS    WHERE DBTYPE = :P_DBTYPE AND ENV = :P_ENV;
    DELETE FROM BD_ADMIN_INFRA.META.TB_ROLES      WHERE DBTYPE = :P_DBTYPE AND ENV = :P_ENV;

    v_r := 'DROPPED FULL: ' || v_db || ' + ' || v_wh_db || ' + ' || v_dropped_roles || ' role(s)';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DROP_DATABASE_FULL','SUCCESS',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION
    WHEN OTHER THEN
        v_sqlstate := SQLSTATE;
        v_sqlerrm  := SQLERRM;
        CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DROP_DATABASE_FULL','ERROR',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;


/* -- SP_RESET_AND_REDEPLOY -------------------------------------
   Nettoie et recree un schema proprement.
   Indispensable en developpement/test : tu travailles sur BRZ_DRC_QEO_C1,
   tu as tout casse, tu veux repartir de zero sans recreer la database.
   
   ROLE REQUIS : ACCOUNTADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_RESET_AND_REDEPLOY(
    P_DBTYPE   VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP      VARCHAR, P_ENV    VARCHAR,
    P_TBL_NAME VARCHAR, P_DDL    VARCHAR,
    P_USER     VARCHAR,
    P_WH_SIZE  VARCHAR  DEFAULT 'XS',
    P_CONFIRM  VARCHAR  DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    IF (:P_CONFIRM != 'RESET_CONFIRMED') THEN
        RETURN 'ABORTED: passer P_CONFIRM=''RESET_CONFIRMED'' pour confirmer le reset de '
            || :P_DBTYPE || '_' || :P_SHTYPE || '_' || :P_OFFRE || '_' || COALESCE(:P_APP,'X') || '_' || :P_ENV;
    END IF;

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_RESET_AND_REDEPLOY','WARN',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','RESET_START','RESET: suppression du schema et recreation complete',NULL,NULL);

    -- 1. Nettoyer le schema (DROP_CONFIRMED pour SP_DROP_SCHEMA_FULL)
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_SCHEMA_FULL(
        :P_DBTYPE, :P_SHTYPE, :P_OFFRE, :P_APP, :P_ENV, 'DROP_CONFIRMED');

    -- 2. Recreer le Tier 2 (schema + roles)
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_SCHEMA(
        :P_DBTYPE, :P_SHTYPE, :P_OFFRE, :P_APP, :P_ENV,
        :P_USER, :P_WH_SIZE, 200, 50, NULL, NULL);

    -- 3. Recreer le Tier 3 (table + vues)
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_TABLE(
        :P_DBTYPE, :P_SHTYPE, :P_OFFRE, :P_APP, :P_ENV,
        :P_TBL_NAME, :P_DDL, :P_WH_SIZE);

    v_r := 'RESET OK: ' || :P_DBTYPE || '_' || :P_SHTYPE || '_' || :P_OFFRE || '_' || COALESCE(:P_APP,'X') || '_' || :P_ENV
         || ' recree en ' || DATEDIFF('millisecond', v_t, CURRENT_TIMESTAMP()) || ' ms';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_RESET_AND_REDEPLOY','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','RESET_DONE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION
    WHEN OTHER THEN
        v_sqlstate := SQLSTATE;
        v_sqlerrm  := SQLERRM;
        CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_RESET_AND_REDEPLOY','ERROR',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;


/* ================================================================
   EXEMPLES D'UTILISATION

-- Dupliquer C1 en H1 (meme structure, sans les donnees) --

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_REPLICATE_ENV(
    'BRZ', 'DRC', 'C1', 'H1', 'FJ6634', 'XS', 200, 50, 'FJ6634'
);
-- Cree BD_BRZ_H1, WH_BRZ_DRC_OE_QEO_XS_H1, RF_*_H1, RS_*_H1...
-- Les schemas sont vides (les tables sont creees mais sans donnees)
-- Pour copier les donnees : utiliser dbt ou Snowflake Replication native

-- Nettoyer un schema pour repartir de zero (dev/test) --

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_RESET_AND_REDEPLOY(
    'BRZ', 'DRC', 'OE', 'QEO', 'C1',
    'POINT_PCE',
    'PCE_ID NUMBER NOT NULL, STATUT VARCHAR(50)',
    'FJ6634', 'XS',
    'RESET_CONFIRMED'
);

-- Supprimer un schema proprement --

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_SCHEMA_FULL(
    'BRZ', 'DRC', 'OE', 'QEO', 'C1', 'DROP_CONFIRMED'
);

-- Supprimer une database entiere (DANGEREUX - dev uniquement) --

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_DATABASE_FULL(
    'BRZ', 'DRC', 'C1', 'DROP_CONFIRMED'
);

-- DEPLOIEMENT SUR UN AUTRE COMPTE SNOWFLAKE ------------------
Pour deployer le framework sur un nouveau compte (ex: compte DRC),
il n'y a pas de magie Snowflake - il faut reexecuter les fichiers SQL.

La procedure recommandee avec SnowSQL CLI :

  snowsql -c compte_drc -f 00_INIT/01_admin_database.sql
  snowsql -c compte_drc -f 00_INIT/02_tags_securite.sql
  snowsql -c compte_drc -f 00_INIT/03_meta_registry.sql
  snowsql -c compte_drc -f 10_PROCEDURES/SP_LOG_EVENT.sql
  snowsql -c compte_drc -f 10_PROCEDURES/SP_BUILD_NAMES.sql
  ... (tous les fichiers 10_PROCEDURES/)
  snowsql -c compte_drc -f 20_DEPLOY/DRC_SLV_OM_C1.sql

Voir 30_DEPLOY_MULTICOMPTE/ pour un script shell automatise.
================================================================ */
