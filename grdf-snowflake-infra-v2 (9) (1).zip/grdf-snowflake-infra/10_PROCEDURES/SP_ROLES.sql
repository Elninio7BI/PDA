/* =================================================================
   SP_ROLES.sql - Creation des roles (3 niveaux de delegation)

   Niveau 1 - Compte    : SP_CREATE_DOMAIN_ROLES  -> RD_*
   Niveau 1 - Database  : SP_CREATE_DB_ROLES      -> RD_DB_*
   Niveau 2 - App/Schema: SP_CREATE_APP_ROLES     -> RA_* + RF_* (incl. TASK)
   Niveau 2 - Schema    : SP_CREATE_SCHEMA_ROLES  -> RS_*
   Utilitaire           : SP_ADD_ROLE             -> Ajouter un RF_* ad hoc
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_DB_ROLES(VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_APP_ROLES(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_SCHEMA_ROLES(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_ADD_ROLE(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);

-- Supprimer les anciennes signatures pour eviter l'erreur ambiguous overloading
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_DOMAIN_ROLES(VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_DATABASE(VARCHAR,VARCHAR,VARCHAR,VARCHAR,NUMBER,VARCHAR);

/* -- SP_CREATE_DOMAIN_ROLES ------------------------------------
   Cree les roles niveau ACCOUNT et DATABASE + les 3 profils RF_DOM_*
   
   RD_ACC_* : 4 roles delegation compte (SYSADMIN/SECADMIN/USRADMIN/ACCADMIN)
   RD_BD_*  : 4 roles delegation database
   RF_DOM_* : 3 profils domaine crees automatiquement (ADMIN/MOE/ANALYST)
              RF_DOM aggre tous les RA_SH du domaine - crees ici car
              ils couvrent TOUTE la couche/domaine sans schema specifique
   
   ROLE REQUIS : ACCOUNTADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_DOMAIN_ROLES(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_ENV VARCHAR, P_USER VARCHAR,
    P_ACCOUNT_CODE VARCHAR DEFAULT 'DFHPRD'
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n      VARIANT;
    v_sys    VARCHAR; v_sec    VARCHAR; v_usr    VARCHAR; v_acc    VARCHAR;
    v_wh     VARCHAR; v_sa     VARCHAR;
    v_dom_adm VARCHAR; v_dom_moe VARCHAR; v_dom_ana VARCHAR;
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,'X','X',:P_ENV,NULL,'XS',:P_ACCOUNT_CODE) INTO v_n;
    v_sys     := v_n:RD_ACC_SYSADMIN::VARCHAR;
    v_sec     := v_n:RD_ACC_SECADMIN::VARCHAR;
    v_usr     := v_n:RD_ACC_USRADMIN::VARCHAR;
    v_acc     := v_n:RD_ACC_ACCADMIN::VARCHAR;
    v_wh      := v_n:WH_DB::VARCHAR;
    v_sa      := v_n:SA_DEPLOY::VARCHAR;
    v_dom_adm := v_n:RF_DOM_ADMIN::VARCHAR;
    v_dom_moe := v_n:RF_DOM_MOE::VARCHAR;
    v_dom_ana := v_n:RF_DOM_ANALYST::VARCHAR;

    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';

    -- Creation RD_ACC_*
    FOR v_role IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_sys,v_sec,v_usr,v_acc)))) DO
        EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS '||v_role.VALUE::VARCHAR;
    END FOR;

    -- Privileges compte-niveau
    EXECUTE IMMEDIATE 'GRANT CREATE USER ON ACCOUNT TO ROLE '       ||v_usr;
    EXECUTE IMMEDIATE 'GRANT CREATE ROLE ON ACCOUNT TO ROLE '       ||v_usr;
    EXECUTE IMMEDIATE 'GRANT MANAGE GRANTS ON ACCOUNT TO ROLE '     ||v_sec;
    EXECUTE IMMEDIATE 'GRANT CREATE DATABASE ON ACCOUNT TO ROLE '   ||v_sys;
    EXECUTE IMMEDIATE 'GRANT CREATE WAREHOUSE ON ACCOUNT TO ROLE '  ||v_sys;
    EXECUTE IMMEDIATE 'GRANT CREATE SHARE ON ACCOUNT TO ROLE '      ||v_acc;
    EXECUTE IMMEDIATE 'GRANT IMPORT SHARE ON ACCOUNT TO ROLE '      ||v_acc;
    EXECUTE IMMEDIATE 'GRANT MONITOR USAGE ON ACCOUNT TO ROLE '     ||v_acc;
    EXECUTE IMMEDIATE 'GRANT CREATE INTEGRATION ON ACCOUNT TO ROLE '||v_acc;

    -- Warehouse domaine partage
    EXECUTE IMMEDIATE 'USE ROLE '||v_sys;
    EXECUTE IMMEDIATE 'CREATE WAREHOUSE IF NOT EXISTS '||v_wh||'
        WAREHOUSE_SIZE=''XSMALL'' AUTO_SUSPEND=60 AUTO_RESUME=TRUE INITIALLY_SUSPENDED=TRUE
        COMMENT=''WH partage '||:P_DBTYPE||'_'||:P_ENV||'''';
    EXECUTE IMMEDIATE 'USE ROLE SECURITYADMIN';
    FOR v_role IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_sys,v_sec,v_usr,v_acc)))) DO
        EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh||' TO ROLE '||v_role.VALUE::VARCHAR;
    END FOR;

    -- Rattachement hierarchie systeme
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_usr||' TO ROLE USERADMIN';
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_sec||' TO ROLE SECURITYADMIN';
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_sys||' TO ROLE SYSADMIN';
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_acc||' TO ROLE SYSADMIN';
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_sys||' TO ROLE '||v_acc;

    -- RF_DOM_* : profils domaine transverses (crees automatiquement)
    -- Pas encore de RA_SH_* a heriter ici (schemas pas encore crees)
    -- Les RA_SH_* sont accordes via SP_SYNC_CROSS_DOMAIN_ROLE a chaque nouveau schema
    EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
    FOR v_role IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_dom_adm,v_dom_moe,v_dom_ana)))) DO
        EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS '||v_role.VALUE::VARCHAR
            ||' COMMENT=''Profil domaine '||:P_DBTYPE||'_'||:P_SHTYPE||'_'||:P_ENV||' - transverse tous schemas''';
        EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh||' TO ROLE '||v_role.VALUE::VARCHAR;
    END FOR;
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_dom_moe||' TO ROLE '||v_dom_adm;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_dom_ana||' TO ROLE '||v_dom_moe;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_dom_adm||' TO ROLE SYSADMIN';

    -- Attribution P_USER sur tous les roles
    FOR v_role IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_sys,v_sec,v_usr,v_acc)))) DO
        EXECUTE IMMEDIATE 'GRANT ROLE '||v_role.VALUE::VARCHAR||' TO USER '||:P_USER;
    END FOR;

    -- Attribution SA (silencieux si absent)
    BEGIN
        FOR v_role IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_sys,v_sec,v_usr,v_acc)))) DO
            EXECUTE IMMEDIATE 'GRANT ROLE '||v_role.VALUE::VARCHAR||' TO USER '||v_sa;
        END FOR;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    v_r := 'OK: RD_ACC_* + RD_BD_* + RF_DOM_* '||:P_DBTYPE||'_'||:P_SHTYPE||'_'||:P_ENV;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_DOMAIN_ROLES','SUCCESS',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'ACCOUNT','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_DOMAIN_ROLES','ERROR',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'ACCOUNT','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;

/* -- SP_CREATE_DB_ROLES ----------------------------------------
   Cree les 3 roles RD_DB_* qui permettent aux equipes de deployer
   leurs schemas SANS avoir besoin des roles systeme.
   ROLE REQUIS : RD_*_USRADMIN + RD_*_SECADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_DB_ROLES(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_ENV VARCHAR, P_USER VARCHAR DEFAULT NULL
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n   VARIANT;
    v_db  VARCHAR; v_wh_db  VARCHAR;
    v_usr VARCHAR; v_sec    VARCHAR; v_sys_dom VARCHAR;
    v_rdb_sys VARCHAR; v_rdb_sec VARCHAR; v_rdb_usr VARCHAR;
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,'X','X',:P_ENV,NULL,'XS',:P_ACCOUNT_CODE) INTO v_n;
    v_db      := v_n:DB::VARCHAR;         v_wh_db  := v_n:WH_DB::VARCHAR;
    v_usr     := v_n:RD_ACC_USRADMIN::VARCHAR; v_sec   := v_n:RD_ACC_SECADMIN::VARCHAR;
    v_sys_dom := v_n:RD_ACC_SYSADMIN::VARCHAR;
    v_rdb_sys := v_n:RD_BD_SYSADMIN::VARCHAR;
    v_rdb_sec := v_n:RD_BD_SECADMIN::VARCHAR;
    v_rdb_usr := v_n:RD_BD_USRADMIN::VARCHAR;

    -- Creation via RD_USRADMIN
    EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
    FOR v_r IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_rdb_sys,v_rdb_sec,v_rdb_usr)))) DO
        EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS '||v_r.VALUE::VARCHAR;
    END FOR;

    -- Grants via RD_SECADMIN
    EXECUTE IMMEDIATE 'USE ROLE '||v_sec;
    EXECUTE IMMEDIATE 'GRANT USAGE, CREATE SCHEMA ON DATABASE '||v_db||' TO ROLE '||v_rdb_sys;
    EXECUTE IMMEDIATE 'GRANT CREATE WAREHOUSE ON ACCOUNT TO ROLE '||v_rdb_sys;
    EXECUTE IMMEDIATE 'GRANT USAGE ON DATABASE '||v_db||' TO ROLE '||v_rdb_sec;
    EXECUTE IMMEDIATE 'GRANT MANAGE GRANTS ON ACCOUNT TO ROLE '||v_rdb_sec;
    EXECUTE IMMEDIATE 'GRANT USAGE ON DATABASE '||v_db||' TO ROLE '||v_rdb_usr;
    EXECUTE IMMEDIATE 'GRANT CREATE ROLE ON ACCOUNT TO ROLE '||v_rdb_usr;
    FOR v_r IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_rdb_sys,v_rdb_sec,v_rdb_usr)))) DO
        EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_db||' TO ROLE '||v_r.VALUE::VARCHAR;
    END FOR;

    -- Hierarchie interne DB : SYSADMIN absorbe les deux autres
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rdb_sec||' TO ROLE '||v_rdb_sys;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rdb_usr||' TO ROLE '||v_rdb_sys;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rdb_sys||' TO ROLE '||v_sys_dom;

    IF (:P_USER IS NOT NULL) THEN
        EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
        EXECUTE IMMEDIATE 'GRANT ROLE '||v_rdb_sys||' TO USER '||:P_USER;
    END IF;

    v_r := 'OK: RD_DB_* '||v_db;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_DB_ROLES','SUCCESS',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_DB_ROLES','ERROR',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;

/* -- SP_CREATE_APP_ROLES ---------------------------------------
   Cree les roles RA_* (techniques) + RF_* (fonctionnels).
   Profils : ADMIN | MOE | ANALYST | TASK
   TASK a EXECUTE TASK et herite de MOE (lecture+ecriture).
   ROLE REQUIS : RD_DB_*_USRADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_APP_ROLES(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP VARCHAR, P_ENV VARCHAR, P_USER VARCHAR
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n   VARIANT;
    v_usr VARCHAR;
    v_ra_own VARCHAR; v_ra_rw VARCHAR; v_ra_ro  VARCHAR;
    v_rf_adm VARCHAR; v_rf_moe VARCHAR; v_rf_ana VARCHAR; v_rf_tsk VARCHAR;
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV) INTO v_n;
    v_usr    := v_n:RD_BD_USRADMIN::VARCHAR;
    v_ra_own := v_n:RA_OWNER::VARCHAR;  v_ra_rw := v_n:RA_RW::VARCHAR;  v_ra_ro := v_n:RA_RO::VARCHAR;
    v_rf_adm := v_n:RF_SH_ADMIN::VARCHAR;  v_rf_moe := v_n:RF_SH_MOE::VARCHAR;
    v_rf_ana := v_n:RF_SH_ANALYST::VARCHAR; v_rf_tsk := v_n:RF_SH_TASK::VARCHAR;

    EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
    FOR v_r IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_ra_own,v_ra_rw,v_ra_ro,v_rf_adm,v_rf_moe,v_rf_ana,v_rf_tsk)))) DO
        EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS '||v_r.VALUE::VARCHAR;
    END FOR;

    -- Hierarchie : RO  c  RW  c  OWNER  c  ADMIN | RO  c  ANALYST | RW  c  MOE  c  TASK
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_ro ||' TO ROLE '||v_ra_rw;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_rw ||' TO ROLE '||v_ra_own;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_own||' TO ROLE '||v_rf_adm;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_ro ||' TO ROLE '||v_rf_ana;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_rw ||' TO ROLE '||v_rf_moe;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rf_moe||' TO ROLE '||v_rf_tsk;

    -- EXECUTE TASK (necessite ACCOUNTADMIN)
    BEGIN
        EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
        EXECUTE IMMEDIATE 'GRANT EXECUTE TASK ON ACCOUNT TO ROLE '||v_rf_tsk;
        EXECUTE IMMEDIATE 'GRANT EXECUTE TASK ON ACCOUNT TO ROLE '||v_rf_adm;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rf_adm||' TO USER '||:P_USER;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rf_moe||' TO USER '||:P_USER;

    v_r := 'OK: RA_*/RF_* '||:P_DBTYPE||'_'||:P_SHTYPE||'_'||COALESCE(:P_APP,'X')||'_'||:P_ENV;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_APP_ROLES','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_APP_ROLES','ERROR',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;

/* -- SP_CREATE_SCHEMA_ROLES ------------------------------------
   Cree les 3 roles RS_* qui rendent une equipe autonome sur son schema.
   OWNER : ALL + cree tables/vues  - Lead technique
   ADMIN : DDL + DML               - Developpeurs seniors
   TEAM  : DML uniquement          - Developpeurs / analystes
   ROLE REQUIS : RD_DB_*_USRADMIN + RD_DB_*_SECADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_SCHEMA_ROLES(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP VARCHAR, P_ENV VARCHAR, P_USER VARCHAR DEFAULT NULL
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n    VARIANT;
    v_sch  VARCHAR; v_wh_app VARCHAR; v_ra_ro  VARCHAR;
    v_usr  VARCHAR; v_sec    VARCHAR;
    v_rdsh_own VARCHAR; v_rdsh_adm VARCHAR; v_rdsh_tea VARCHAR;
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV) INTO v_n;
    v_sch    := v_n:FULL_SCHEMA::VARCHAR; v_wh_app := v_n:WH_APP::VARCHAR;
    v_ra_ro  := v_n:RA_RO::VARCHAR;
    v_usr    := v_n:RD_BD_USRADMIN::VARCHAR; v_sec := v_n:RD_BD_SECADMIN::VARCHAR;
    v_rdsh_own := v_n:RF_SH_ADMIN::VARCHAR; v_rdsh_adm := v_n:RF_SH_ADMIN::VARCHAR; v_rdsh_tea := v_n:RF_SH_MOE::VARCHAR;

    EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
    FOR v_r IN (SELECT r FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(v_rdsh_own,v_rdsh_adm,v_rdsh_tea)))) DO
        EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS '||v_r.VALUE::VARCHAR;
    END FOR;

    EXECUTE IMMEDIATE 'USE ROLE '||v_sec;

    -- RS_OWNER : ALL sur le schema
    EXECUTE IMMEDIATE 'GRANT USAGE ON SCHEMA '||v_sch||' TO ROLE '||v_rdsh_own;
    EXECUTE IMMEDIATE 'GRANT ALL PRIVILEGES ON SCHEMA '||v_sch||' TO ROLE '||v_rdsh_own;
    EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_app||' TO ROLE '||v_rdsh_own;

    -- RS_ADMIN : DDL + DML
    EXECUTE IMMEDIATE 'GRANT USAGE ON SCHEMA '||v_sch||' TO ROLE '||v_rdsh_adm;
    FOR v_priv IN (SELECT p FROM TABLE(FLATTEN(ARRAY_CONSTRUCT('CREATE TABLE','CREATE VIEW','CREATE MATERIALIZED VIEW','CREATE STAGE','CREATE STREAM','CREATE PIPE')))) DO
        EXECUTE IMMEDIATE 'GRANT '||v_priv.VALUE::VARCHAR||' ON SCHEMA '||v_sch||' TO ROLE '||v_rdsh_adm;
    END FOR;
    EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_app||' TO ROLE '||v_rdsh_adm;

    -- RS_TEAM : DML uniquement
    EXECUTE IMMEDIATE 'GRANT USAGE ON SCHEMA '||v_sch||' TO ROLE '||v_rdsh_tea;
    EXECUTE IMMEDIATE 'GRANT SELECT,INSERT,UPDATE,DELETE ON FUTURE TABLES IN SCHEMA '||v_sch||' TO ROLE '||v_rdsh_tea;
    EXECUTE IMMEDIATE 'GRANT SELECT ON FUTURE VIEWS IN SCHEMA '||v_sch||' TO ROLE '||v_rdsh_tea;
    EXECUTE IMMEDIATE 'GRANT SELECT ON ALL TABLES IN SCHEMA '||v_sch||' TO ROLE '||v_rdsh_tea;
    EXECUTE IMMEDIATE 'GRANT SELECT ON ALL VIEWS IN SCHEMA '  ||v_sch||' TO ROLE '||v_rdsh_tea;
    EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_app||' TO ROLE '||v_rdsh_tea;

    -- Hierarchie TEAM  c  ADMIN  c  OWNER + RA_RO pour valider les donnees
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rdsh_tea||' TO ROLE '||v_rdsh_adm;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_rdsh_adm||' TO ROLE '||v_rdsh_own;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_ro  ||' TO ROLE '||v_rdsh_own;

    IF (:P_USER IS NOT NULL) THEN
        EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
        EXECUTE IMMEDIATE 'GRANT ROLE '||v_rdsh_own||' TO USER '||:P_USER;
    END IF;

    v_r := 'OK: RS_* pour '||v_sch;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_SCHEMA_ROLES','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_SCHEMA_ROLES','ERROR',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;

/* -- SP_ADD_ROLE -----------------------------------------------
   Ajoute un profil fonctionnel RF_* personnalise a tout moment.
   P_PROFIL   : DEV | MOA | ETL | BI | REPORTING | ... (libre)
   P_ACCES    : RO | RW | OWNER
   P_USERS    : liste separee par virgule (optionnel)
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_ADD_ROLE(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP VARCHAR, P_ENV VARCHAR,
    P_PROFIL VARCHAR, P_ACCES VARCHAR,  -- 'RO' | 'RW' | 'OWNER'
    P_USERS  VARCHAR DEFAULT NULL,
    P_WH_SIZE VARCHAR DEFAULT 'XS'
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n       VARIANT;
    v_new_role VARCHAR; v_parent VARCHAR; v_wh_app VARCHAR;
    v_usr VARCHAR; v_sec VARCHAR;
    v_user_arr ARRAY; v_i INTEGER;
BEGIN
    IF (:P_ACCES NOT IN ('RO','RW','OWNER')) THEN
        RETURN 'ERREUR : P_ACCES doit etre RO, RW ou OWNER. Recu : '||:P_ACCES;
    END IF;

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,NULL,:P_WH_SIZE) INTO v_n;
    v_usr     := v_n:RD_BD_USRADMIN::VARCHAR;
    v_sec     := v_n:RD_BD_SECADMIN::VARCHAR;
    v_wh_app  := v_n:WH_APP::VARCHAR;
    v_new_role:= 'RF_'||:P_DBTYPE||'_'||:P_SHTYPE||
                 CASE WHEN :P_APP IS NOT NULL AND TRIM(:P_APP)!='' THEN '_'||:P_APP ELSE '' END||
                 '_'||UPPER(:P_PROFIL)||'_'||:P_ENV;
    v_parent  := CASE :P_ACCES
                    WHEN 'RO'    THEN v_n:RA_RO::VARCHAR
                    WHEN 'RW'    THEN v_n:RA_RW::VARCHAR
                    WHEN 'OWNER' THEN v_n:RA_OWNER::VARCHAR
                 END;

    EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
    EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS '||v_new_role;

    EXECUTE IMMEDIATE 'USE ROLE '||v_sec;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_parent  ||' TO ROLE '||v_new_role;
    EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_app||' TO ROLE '||v_new_role;

    IF (:P_USERS IS NOT NULL AND TRIM(:P_USERS)!='') THEN
        EXECUTE IMMEDIATE 'USE ROLE '||v_usr;
        v_user_arr := STRTOK_TO_ARRAY(:P_USERS, ',');
        v_i := 0;
        WHILE (v_i < ARRAY_SIZE(v_user_arr)) DO
            LET u VARCHAR := TRIM(v_user_arr[v_i]::VARCHAR);
            IF (u!='') THEN EXECUTE IMMEDIATE 'GRANT ROLE '||v_new_role||' TO USER '||u; END IF;
            v_i := v_i + 1;
        END WHILE;
    END IF;

    RETURN 'OK: '||v_new_role||' cree (herite de '||v_parent||')';
END;
$$;
