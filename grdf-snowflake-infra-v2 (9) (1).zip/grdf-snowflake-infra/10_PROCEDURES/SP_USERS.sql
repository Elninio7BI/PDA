/* =================================================================
   SP_USERS.sql - Gestion du cycle de vie des utilisateurs
   
   SP_CREATE_USER       -> Creer un utilisateur (humain, service, legacy)
   SP_ALTER_USER        -> Modifier (MDP, role defaut, WH defaut, cle RSA)
   SP_DROP_USER         -> Supprimer un utilisateur
   SP_SET_RSA_KEY       -> Configurer une cle RSA pour l'auth pipeline
   
   Tous les utilisateurs sont traces dans BD_ADMIN_INFRA.META.TB_USERS
   et tagueS automatiquement (application + environnement).
   
   TYPES D'UTILISATEURS :
     PERSON   -> Compte nominatif humain (ex: FJ6634)
     SERVICE  -> Compte pipeline CI/CD TYPE=SERVICE, pas d'UI
     LEGACY   -> Compte applicatif ancien format (pour compatibilite)
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_USER(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_SET_RSA_KEY(VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_ALTER_USER(VARCHAR,VARCHAR,VARCHAR,VARCHAR,BOOLEAN);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_USER(VARCHAR,VARCHAR);


/* -- SP_CREATE_USER --------------------------------------------
   Cree un utilisateur Snowflake et l'enregistre dans META.
   ROLE REQUIS : RD_*_USRADMIN (ou ACCOUNTADMIN pour TYPE=SERVICE)
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_USER(
    P_DBTYPE       VARCHAR,     -- Domaine/couche de rattachement
    P_SHTYPE       VARCHAR,
    P_ENV          VARCHAR,
    P_USER_NAME    VARCHAR,     -- Identifiant Snowflake (ex: FJ6634, SA_ETL_DRC)
    P_USER_TYPE    VARCHAR,     -- PERSON | SERVICE | LEGACY
    P_DEFAULT_ROLE VARCHAR,     -- Role par defaut
    P_DEFAULT_WH   VARCHAR,     -- Warehouse par defaut
    P_EMAIL        VARCHAR DEFAULT NULL,
    P_DISPLAY_NAME VARCHAR DEFAULT NULL,
    P_COMMENT      VARCHAR DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_n      VARIANT;
    v_usr_admin VARCHAR;
    v_cnt    NUMBER;
    v_t      TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE, :P_SHTYPE, 'X', 'X', :P_ENV) INTO v_n;
    v_usr_admin := v_n:RD_ACC_USRADMIN::VARCHAR;

    -- TYPE=SERVICE necessite ACCOUNTADMIN (limitation Snowflake)
    IF (UPPER(:P_USER_TYPE) = 'SERVICE') THEN
        EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
        EXECUTE IMMEDIATE '
            CREATE USER IF NOT EXISTS ' || :P_USER_NAME || '
            TYPE = SERVICE
            DEFAULT_ROLE      = ' || :P_DEFAULT_ROLE || '
            DEFAULT_WAREHOUSE = ' || :P_DEFAULT_WH   || '
            MUST_CHANGE_PASSWORD = FALSE
            COMMENT = ''' || COALESCE(:P_COMMENT, 'SA cree par framework GRDF') || '''';
    ELSE
        EXECUTE IMMEDIATE 'USE ROLE ' || v_usr_admin;
        EXECUTE IMMEDIATE '
            CREATE USER IF NOT EXISTS ' || :P_USER_NAME || '
            DEFAULT_ROLE      = ' || :P_DEFAULT_ROLE || '
            DEFAULT_WAREHOUSE = ' || :P_DEFAULT_WH   || '
            MUST_CHANGE_PASSWORD = ' || CASE UPPER(:P_USER_TYPE) WHEN 'PERSON' THEN 'TRUE' ELSE 'FALSE' END || '
            ' || CASE WHEN :P_EMAIL IS NOT NULL THEN 'EMAIL = ''' || :P_EMAIL || '''' ELSE '' END || '
            ' || CASE WHEN :P_DISPLAY_NAME IS NOT NULL THEN 'DISPLAY_NAME = ''' || :P_DISPLAY_NAME || '''' ELSE '' END || '
            COMMENT = ''' || COALESCE(:P_COMMENT, 'Utilisateur cree par framework GRDF') || '''';
    END IF;

    -- Tagging automatique
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_OBJECT(:P_USER_NAME, 'USER', :P_DBTYPE, :P_SHTYPE, NULL, :P_ENV);

    -- Registre META
    SELECT COUNT(*) INTO v_cnt FROM BD_ADMIN_INFRA.META.TB_USERS WHERE USER_NAME = :P_USER_NAME;
    IF (v_cnt = 0) THEN
        INSERT INTO BD_ADMIN_INFRA.META.TB_USERS (USER_NAME, USER_TYPE, DEFAULT_ROLE, DEFAULT_WH, DBTYPE, SHTYPE, ENV)
        VALUES (:P_USER_NAME, UPPER(:P_USER_TYPE), :P_DEFAULT_ROLE, :P_DEFAULT_WH, :P_DBTYPE, :P_SHTYPE, :P_ENV);
    END IF;

    v_r := 'OK: ' || UPPER(:P_USER_TYPE) || ' ' || :P_USER_NAME || ' cree';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_USER','SUCCESS',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'ACCOUNT','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION
    WHEN OTHER THEN
        v_sqlstate := SQLSTATE;
        v_sqlerrm  := SQLERRM;
        CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_USER','ERROR',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'ACCOUNT','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;


/* -- SP_SET_RSA_KEY --------------------------------------------
   Configure la cle RSA publique pour un compte de service.
   A appeler apres SP_CREATE_USER pour les comptes TYPE=SERVICE.
   ROLE REQUIS : ACCOUNTADMIN (ALTER USER RSA = exclusif ACCOUNTADMIN)
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_SET_RSA_KEY(
    P_USER_NAME    VARCHAR,
    P_RSA_PUBLIC_KEY VARCHAR   -- Cle publique RSA (sans les headers BEGIN/END)
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
BEGIN
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'ALTER USER ' || :P_USER_NAME
        || ' SET RSA_PUBLIC_KEY = ''' || :P_RSA_PUBLIC_KEY || '''';

    -- Mettre a jour le registre META
    UPDATE BD_ADMIN_INFRA.META.TB_USERS
    SET RSA_CONFIGURED = TRUE
    WHERE USER_NAME = :P_USER_NAME;

    RETURN 'OK: Cle RSA configuree pour ' || :P_USER_NAME;
EXCEPTION
    WHEN OTHER THEN RETURN 'ERR [' || SQLSTATE || ']: ' || SQLERRM;
END;
$$;


/* -- SP_ALTER_USER ---------------------------------------------
   Modifie les attributs d'un utilisateur existant.
   Passer NULL pour les parametres a ne pas modifier.
   ROLE REQUIS : RD_*_USRADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_ALTER_USER(
    P_USER_NAME    VARCHAR,
    P_NEW_PASSWORD VARCHAR  DEFAULT NULL,  -- NULL = ne pas changer
    P_DEFAULT_ROLE VARCHAR  DEFAULT NULL,
    P_DEFAULT_WH   VARCHAR  DEFAULT NULL,
    P_DISABLED     BOOLEAN  DEFAULT NULL   -- TRUE = desactiver le compte
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_parts ARRAY := ARRAY_CONSTRUCT();
    v_sql   VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';

    IF (:P_NEW_PASSWORD IS NOT NULL) THEN
        EXECUTE IMMEDIATE 'ALTER USER ' || :P_USER_NAME
            || ' SET PASSWORD = ''' || :P_NEW_PASSWORD || ''' MUST_CHANGE_PASSWORD = TRUE';
    END IF;
    IF (:P_DEFAULT_ROLE IS NOT NULL) THEN
        EXECUTE IMMEDIATE 'ALTER USER ' || :P_USER_NAME || ' SET DEFAULT_ROLE = ' || :P_DEFAULT_ROLE;
        UPDATE BD_ADMIN_INFRA.META.TB_USERS SET DEFAULT_ROLE = :P_DEFAULT_ROLE WHERE USER_NAME = :P_USER_NAME;
    END IF;
    IF (:P_DEFAULT_WH IS NOT NULL) THEN
        EXECUTE IMMEDIATE 'ALTER USER ' || :P_USER_NAME || ' SET DEFAULT_WAREHOUSE = ' || :P_DEFAULT_WH;
        UPDATE BD_ADMIN_INFRA.META.TB_USERS SET DEFAULT_WH = :P_DEFAULT_WH WHERE USER_NAME = :P_USER_NAME;
    END IF;
    IF (:P_DISABLED IS NOT NULL) THEN
        EXECUTE IMMEDIATE 'ALTER USER ' || :P_USER_NAME
            || ' SET DISABLED = ' || CASE WHEN :P_DISABLED THEN 'TRUE' ELSE 'FALSE' END;
    END IF;

    RETURN 'OK: ' || :P_USER_NAME || ' modifie';
EXCEPTION
    WHEN OTHER THEN RETURN 'ERR [' || SQLSTATE || ']: ' || SQLERRM;
END;
$$;


/* -- SP_DROP_USER ----------------------------------------------
   Supprime un utilisateur et le retire du registre META.
   ROLE REQUIS : RD_*_USRADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DROP_USER(
    P_USER_NAME VARCHAR,
    P_CONFIRM   VARCHAR  -- Passer 'DROP_CONFIRMED' pour confirmer
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
BEGIN
    IF (:P_CONFIRM != 'DROP_CONFIRMED') THEN
        RETURN 'ABORTED: passer P_CONFIRM=''DROP_CONFIRMED'' pour confirmer la suppression de ' || :P_USER_NAME;
    END IF;

    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'DROP USER IF EXISTS ' || :P_USER_NAME;

    DELETE FROM BD_ADMIN_INFRA.META.TB_USERS WHERE USER_NAME = :P_USER_NAME;

    RETURN 'OK: ' || :P_USER_NAME || ' supprime';
EXCEPTION
    WHEN OTHER THEN RETURN 'ERR [' || SQLSTATE || ']: ' || SQLERRM;
END;
$$;


/* ================================================================
   EXEMPLES D'UTILISATION

-- Creer un utilisateur nominatif (humain)
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_USER(
    'BRZ', 'DRC', 'C1',
    'JEAN_DUPONT',         -- identifiant
    'PERSON',              -- type
    'RF_BRZ_DRC_QEO_ANALYST_C1',  -- role par defaut
    'WH_BRZ_DRC_OE_QEO_XS_C1',   -- warehouse par defaut
    'jean.dupont@grdf.fr', -- email
    'Jean Dupont',         -- display name
    'Analyste data DRC'
);

-- Creer un compte de service CI/CD (TYPE=SERVICE, pas de connexion UI)
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_USER(
    'BRZ', 'DRC', 'C1',
    'SA_ETL_DRC_C1',
    'SERVICE',
    'RF_BRZ_DRC_QEO_ETL_C1',
    'WH_BRZ_DRC_OE_QEO_XS_C1',
    NULL, NULL,
    'Compte service pipeline dbt DRC'
);
-- Puis configurer la cle RSA
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_SET_RSA_KEY('SA_ETL_DRC_C1', 'MIIBIjANBgkq...');

-- Modifier le warehouse par defaut d'un utilisateur
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_ALTER_USER(
    'JEAN_DUPONT', NULL, NULL, 'WH_BRZ_DRC_OE_QEO_M_C1', NULL
);

-- Desactiver un compte (depart employe)
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_ALTER_USER('JEAN_DUPONT', NULL, NULL, NULL, TRUE);

-- Supprimer definitivement
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_USER('JEAN_DUPONT', 'DROP_CONFIRMED');
================================================================ */
