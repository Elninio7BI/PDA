/* =================================================================
   SP_STORAGE.sql - Storage Integrations S3/Azure + PrivateLink
   
   SP_CREATE_STORAGE_INT  -> Creer une integration S3 ou Azure
   SP_DROP_STORAGE_INT    -> Supprimer une integration + role RA
   SP_GET_STORAGE_CONFIG  -> Obtenir la config (ARN IAM pour S3)
   
   CONCEPT :
   Une Storage Integration est un objet Snowflake compte-niveau
   qui permet d'acceder a un bucket S3 ou Azure Blob Storage.
   Elle requiert ACCOUNTADMIN et USE_PRIVATELINK_ENDPOINT si GRDF
   utilise une connexion PrivateLink (recommande en prod).
   
   A chaque integration creee, un role RA d'acces est cree et
   enregistre dans META.
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_STORAGE_INT(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,BOOLEAN);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_GET_STORAGE_CONFIG(VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_STORAGE_INT(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);


/* -- SP_CREATE_STORAGE_INT -------------------------------------
   Cree une Storage Integration S3 ou Azure et le role RA associe.
   
   P_NAME          : identifiant de l'integration (ex: S3INT_DRC_BRONZE)
   P_PROVIDER      : 'S3' ou 'AZURE'
   P_LOCATION      : s3://grdf-bucket/prefix/ ou azure://...
   P_AWS_ROLE_ARN  : role IAM AWS (uniquement pour S3)
   P_AZURE_TENANT  : tenant Azure (uniquement pour Azure)
   P_PRIVATELINK   : TRUE = utiliser PrivateLink (recommande en prod)
   P_DBTYPE / P_SHTYPE / P_ENV : contexte pour le tag et le role RA
   
   ROLE REQUIS : ACCOUNTADMIN (CREATE INTEGRATION exclusif)
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_STORAGE_INT(
    P_NAME         VARCHAR,
    P_PROVIDER     VARCHAR,    -- 'S3' | 'AZURE'
    P_LOCATION     VARCHAR,    -- s3://bucket/prefix/ ou azure://container/
    P_DBTYPE       VARCHAR,
    P_SHTYPE       VARCHAR,
    P_ENV          VARCHAR,
    P_AWS_ROLE_ARN VARCHAR DEFAULT NULL,   -- Pour S3 uniquement
    P_AZURE_TENANT VARCHAR DEFAULT NULL,   -- Pour Azure uniquement
    P_PRIVATELINK  BOOLEAN DEFAULT TRUE    -- TRUE en prod (GRDF utilise PrivateLink)
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_n         VARIANT;
    v_usr       VARCHAR;
    v_sys       VARCHAR;
    v_int_name  VARCHAR;
    v_ra_name   VARCHAR;
    v_sql       VARCHAR;
    v_cnt       NUMBER;
    v_t         TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE, :P_SHTYPE, 'X', 'X', :P_ENV) INTO v_n;
    v_usr      := v_n:RD_ACC_USRADMIN::VARCHAR;
    v_sys      := v_n:RD_ACC_SYSADMIN::VARCHAR;
    v_int_name := LOWER(:P_NAME);
    v_ra_name  := 'RA_STGINT_' || UPPER(:P_DBTYPE) || '_' || UPPER(:P_SHTYPE) || '_' || UPPER(REPLACE(:P_NAME, '-', '_')) || '_' || :P_ENV;

    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';

    -- Construction du SQL selon le provider
    IF (UPPER(:P_PROVIDER) = 'S3') THEN
        IF (:P_AWS_ROLE_ARN IS NULL) THEN
            RETURN 'ERREUR: P_AWS_ROLE_ARN obligatoire pour S3';
        END IF;
        v_sql := '
            CREATE STORAGE INTEGRATION IF NOT EXISTS ' || v_int_name || '
            TYPE = EXTERNAL_STAGE
            STORAGE_PROVIDER = ''S3''
            ENABLED = TRUE
            STORAGE_AWS_ROLE_ARN = ''' || :P_AWS_ROLE_ARN || '''
            STORAGE_ALLOWED_LOCATIONS = (''' || :P_LOCATION || ''')' ||
            CASE WHEN :P_PRIVATELINK THEN '
            USE_PRIVATELINK_ENDPOINT = TRUE' ELSE '' END;

    ELSEIF (UPPER(:P_PROVIDER) = 'AZURE') THEN
        IF (:P_AZURE_TENANT IS NULL) THEN
            RETURN 'ERREUR: P_AZURE_TENANT obligatoire pour Azure';
        END IF;
        v_sql := '
            CREATE STORAGE INTEGRATION IF NOT EXISTS ' || v_int_name || '
            TYPE = EXTERNAL_STAGE
            STORAGE_PROVIDER = ''AZURE''
            ENABLED = TRUE
            AZURE_TENANT_ID = ''' || :P_AZURE_TENANT || '''
            STORAGE_ALLOWED_LOCATIONS = (''' || :P_LOCATION || ''')';
    ELSE
        RETURN 'ERREUR: P_PROVIDER doit etre S3 ou AZURE';
    END IF;

    EXECUTE IMMEDIATE v_sql;

    -- Tag de l'integration
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_OBJECT(v_int_name, 'STORAGE INTEGRATION', :P_DBTYPE, :P_SHTYPE, NULL, :P_ENV);

    -- Creer le role RA d'acces
    EXECUTE IMMEDIATE 'USE ROLE ' || v_usr;
    EXECUTE IMMEDIATE 'CREATE ROLE IF NOT EXISTS ' || v_ra_name
        || ' COMMENT = ''Acces Storage Integration ' || v_int_name || '''';

    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'GRANT USAGE ON INTEGRATION ' || v_int_name || ' TO ROLE ' || v_ra_name;
    EXECUTE IMMEDIATE 'GRANT ROLE ' || v_ra_name || ' TO ROLE ' || v_sys;

    RETURN 'OK: ' || v_int_name || ' cree + RA ' || v_ra_name || ' - '
        || CASE WHEN :P_PROVIDER = 'S3' AND :P_PRIVATELINK THEN '[!] Configurer la trust policy IAM avec DESC INTEGRATION' ELSE '' END;
EXCEPTION
    WHEN OTHER THEN RETURN 'ERR [' || SQLSTATE || ']: ' || SQLERRM;
END;
$$;


/* -- SP_GET_STORAGE_CONFIG -------------------------------------
   Recupere la configuration necessaire pour finaliser l'integration.
   Pour S3 : retourne le Storage AWS IAM User ARN et External ID
             a configurer dans la trust policy du role IAM AWS.
   ROLE REQUIS : ACCOUNTADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_GET_STORAGE_CONFIG(P_INT_NAME VARCHAR)
RETURNS TABLE (PROPERTY VARCHAR, VALUE VARCHAR, DESCRIPTION VARCHAR)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_query_id VARCHAR;
    v_result   RESULTSET;   -- obligatoire : RETURN TABLE(SELECT...) inline n'est pas supporte
BEGIN
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'DESC INTEGRATION ' || :P_INT_NAME;
    SELECT LAST_QUERY_ID() INTO v_query_id;

    v_result := (
        SELECT
            "property"        AS PROPERTY,
            "property_value"  AS VALUE,
            CASE "property"
                WHEN 'STORAGE_AWS_IAM_USER_ARN'
                    THEN '-> Configurer dans la trust policy du role IAM AWS'
                WHEN 'STORAGE_AWS_EXTERNAL_ID'
                    THEN '-> Configurer comme sts:ExternalId dans la trust policy'
                WHEN 'AZURE_CONSENT_URL'
                    THEN '-> Ouvrir cette URL pour accorder les permissions Azure'
                ELSE ''
            END AS DESCRIPTION
        FROM TABLE(RESULT_SCAN(:v_query_id))
        WHERE "property" IN (
            'STORAGE_AWS_IAM_USER_ARN',
            'STORAGE_AWS_EXTERNAL_ID',
            'AZURE_CONSENT_URL',
            'STORAGE_ALLOWED_LOCATIONS',
            'ENABLED'
        )
    );
    RETURN TABLE(v_result);
END;
$$;


/* -- SP_DROP_STORAGE_INT ---------------------------------------
   Supprime une integration et son role RA associe.
   ROLE REQUIS : ACCOUNTADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DROP_STORAGE_INT(
    P_NAME   VARCHAR,
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_ENV VARCHAR,
    P_CONFIRM VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_n     VARIANT;
    v_usr   VARCHAR;
    v_int_name VARCHAR;
    v_ra_name  VARCHAR;
BEGIN
    IF (:P_CONFIRM != 'DROP_CONFIRMED') THEN
        RETURN 'ABORTED: passer P_CONFIRM=''DROP_CONFIRMED'' pour confirmer';
    END IF;

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE, :P_SHTYPE, 'X', 'X', :P_ENV) INTO v_n;
    v_usr      := v_n:RD_ACC_USRADMIN::VARCHAR;
    v_int_name := LOWER(:P_NAME);
    v_ra_name  := 'RA_STGINT_' || UPPER(:P_DBTYPE) || '_' || UPPER(:P_SHTYPE) || '_' || UPPER(REPLACE(:P_NAME, '-', '_')) || '_' || :P_ENV;

    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'DROP INTEGRATION IF EXISTS ' || v_int_name;

    EXECUTE IMMEDIATE 'USE ROLE ' || v_usr;
    EXECUTE IMMEDIATE 'DROP ROLE IF EXISTS ' || v_ra_name;

    RETURN 'OK: ' || v_int_name || ' + ' || v_ra_name || ' supprimes';
END;
$$;


/* ================================================================
   EXEMPLES D'UTILISATION

-- S3 avec PrivateLink (standard GRDF prod) --

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_STORAGE_INT(
    'S3INT_DRC_BRONZE',               -- nom de l'integration
    'S3',                             -- provider
    's3://grdf-datalake-brz/',        -- bucket + prefix
    'BRZ', 'DRC', 'C1',              -- contexte
    'arn:aws:iam::123456789:role/snowflake-grdf-role',  -- role IAM
    NULL,                             -- Azure tenant (inutile pour S3)
    TRUE                              -- PrivateLink active
);
-- Resultat : S3INT_DRC_BRONZE cree + RA_STGINT_BRZ_DRC_S3INT_DRC_BRONZE_C1

-- IMPORTANT : apres creation, recuperer les infos IAM
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_GET_STORAGE_CONFIG('S3INT_DRC_BRONZE');
-- Retourne STORAGE_AWS_IAM_USER_ARN et STORAGE_AWS_EXTERNAL_ID
-- A configurer dans la trust policy du role IAM AWS avant que ca marche

-- Azure --

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_STORAGE_INT(
    'AZINT_DRC_SILVER',
    'AZURE',
    'azure://grdfstorageaccount.blob.core.windows.net/silver/',
    'DRC', 'SLV', 'C1',
    NULL,
    'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'  -- Azure Tenant ID
);

-- Supprimer une integration --

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DROP_STORAGE_INT(
    'S3INT_DRC_BRONZE', 'BRZ', 'DRC', 'C1', 'DROP_CONFIRMED'
);
================================================================ */
