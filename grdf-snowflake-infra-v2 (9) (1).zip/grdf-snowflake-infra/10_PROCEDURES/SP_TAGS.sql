/* =================================================================
   SP_TAGS.sql - Application des tags sur les objets Snowflake
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_OBJECT(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_COLUMN(VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_PROTECT_TABLE_DCP(VARCHAR,VARCHAR);

/* -- SP_TAG_OBJECT -----------------------------------------------
   Pose les 4 tags contextuels sur n'importe quel objet Snowflake.
   P_TYPE : DATABASE | WAREHOUSE | SCHEMA | TABLE | VIEW | ROLE
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_TAG_OBJECT(
    P_OBJECT VARCHAR, P_TYPE VARCHAR,
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_APP VARCHAR, P_ENV VARCHAR
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_app  VARCHAR;
    v_sql  VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    v_app := CASE WHEN :P_APP IS NULL OR TRIM(:P_APP)=''
                  THEN LOWER(:P_DBTYPE)
                  ELSE LOWER(:P_DBTYPE)||'_'||LOWER(:P_APP) END;

    v_sql := 'ALTER '||:P_TYPE||' '||:P_OBJECT||' SET
        TAG BD_ADMIN_INFRA.TAGS.APPLICATION   = '''||v_app           ||''',
            BD_ADMIN_INFRA.TAGS.ENVIRONNEMENT = '''||LOWER(:P_ENV)   ||''',
            BD_ADMIN_INFRA.TAGS.COUCHE        = '''||UPPER(:P_DBTYPE)||''''||
        CASE WHEN :P_SHTYPE IS NOT NULL AND TRIM(:P_SHTYPE)!=''
             THEN ', BD_ADMIN_INFRA.TAGS.DOMAINE = '''||LOWER(:P_SHTYPE)||''''
             ELSE '' END;

    EXECUTE IMMEDIATE v_sql;
    RETURN 'TAGGED '||:P_TYPE||' '||:P_OBJECT;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    RETURN 'TAG_WARN ['||SQLSTATE||']: '||SQLERRM;
END;
$$;


/* -- SP_TAG_COLUMN -----------------------------------------------
   Pose les tags de securite DCP et confidentialite sur une colonne.
   Detecte le type reel de la colonne pour appliquer la bonne
   masking policy automatiquement.

   Exemple :
     CALL SP_TAG_COLUMN('BD_BRZ_C1.SH_DRC_OE_QEO.TB_OE_POINT_PCE',
                        'EMAIL', 'sensible', 'C3');
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_TAG_COLUMN(
    P_TABLE  VARCHAR,  -- BD.SCHEMA.TABLE complet
    P_COL    VARCHAR,  -- Nom de la colonne
    P_DCP    VARCHAR,  -- 'normal' | 'sensible' | NULL
    P_CONF   VARCHAR   -- 'C1' | 'C2' | 'C3' | 'C4' | NULL
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_res      VARCHAR := '';
    v_col_type VARCHAR := '';
    v_query_id VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    -- -- Detecter le type reel de la colonne ----------------------
    -- Decomposer BD.SCHEMA.TABLE en 3 parties
    LET v_parts ARRAY := STRTOK_TO_ARRAY(:P_TABLE, '.');
    LET v_db    VARCHAR := TRIM(v_parts[0]::VARCHAR);
    LET v_sch   VARCHAR := TRIM(v_parts[1]::VARCHAR);
    LET v_tbl   VARCHAR := TRIM(v_parts[2]::VARCHAR);

    -- CORRECTION : construire le nom complet dans une variable
    -- avant de le passer a IDENTIFIER() - la concatenation || 
    -- n'est pas supportee directement dans IDENTIFIER()
    LET v_info_schema VARCHAR := v_db || '.INFORMATION_SCHEMA.COLUMNS';

    SELECT UPPER(DATA_TYPE) INTO v_col_type
    FROM IDENTIFIER(:v_info_schema)
    WHERE TABLE_SCHEMA = UPPER(:v_sch)
      AND TABLE_NAME   = UPPER(:v_tbl)
      AND COLUMN_NAME  = UPPER(:P_COL)
    LIMIT 1;

    -- Si la colonne n'est pas trouvee, fallback TEXT
    IF (v_col_type IS NULL) THEN
        v_col_type := 'TEXT';
    END IF;

    -- -- Application tag + masking policy DCP ---------------------
    IF (:P_DCP IS NOT NULL AND TRIM(:P_DCP) != '') THEN
        EXECUTE IMMEDIATE 'ALTER TABLE ' || :P_TABLE
            || ' MODIFY COLUMN ' || :P_COL
            || ' SET TAG BD_ADMIN_INFRA.TAGS.DCP = ''' || LOWER(:P_DCP) || '''';
        v_res := v_res || 'DCP=' || :P_DCP || ' ';

        IF (LOWER(:P_DCP) = 'sensible') THEN
            LET v_dcp_policy VARCHAR :=
                CASE
                    WHEN v_col_type IN ('TEXT','VARCHAR','STRING','CHAR','CHARACTER',
                                        'NCHAR','NVARCHAR','NVARCHAR2','CHAR VARYING','NCHAR VARYING')
                        THEN 'BD_ADMIN_INFRA.TAGS.MP_DCP_STRING'
                    WHEN v_col_type IN ('NUMBER','DECIMAL','NUMERIC','INT','INTEGER',
                                        'BIGINT','SMALLINT','TINYINT','BYTEINT',
                                        'FLOAT','FLOAT4','FLOAT8','DOUBLE','DOUBLE PRECISION','REAL')
                        THEN 'BD_ADMIN_INFRA.TAGS.MP_DCP_NUMBER'
                    WHEN v_col_type = 'DATE'
                        THEN 'BD_ADMIN_INFRA.TAGS.MP_DCP_DATE'
                    WHEN v_col_type IN ('TIMESTAMP_NTZ','TIMESTAMP_LTZ','TIMESTAMP_TZ',
                                        'TIMESTAMP','DATETIME')
                        THEN 'BD_ADMIN_INFRA.TAGS.MP_DCP_TIMESTAMP'
                    ELSE 'BD_ADMIN_INFRA.TAGS.MP_DCP_STRING'
                END;

            BEGIN
                EXECUTE IMMEDIATE 'ALTER TABLE ' || :P_TABLE
                    || ' MODIFY COLUMN ' || :P_COL
                    || ' SET MASKING POLICY ' || v_dcp_policy
                    || ' USING (' || :P_COL || ')';
                v_res := v_res || '[masking:' || v_dcp_policy || '] ';
            EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
                -- Type incompatible (VARIANT, ARRAY, OBJECT) : tag pose, masking ignore
                v_res := v_res || '[masking_skipped:' || v_col_type || '] ';
            END;
        END IF;
    END IF;

    -- -- Application tag + masking policy Confidentialite ---------
    IF (:P_CONF IS NOT NULL AND TRIM(:P_CONF) != '') THEN
        EXECUTE IMMEDIATE 'ALTER TABLE ' || :P_TABLE
            || ' MODIFY COLUMN ' || :P_COL
            || ' SET TAG BD_ADMIN_INFRA.TAGS.CONFIDENTIALITE = ''' || UPPER(:P_CONF) || '''';
        v_res := v_res || 'CONF=' || :P_CONF || ' ';

        IF (:P_CONF IN ('C3','C4')) THEN
            LET v_conf_policy VARCHAR :=
                CASE :P_CONF
                    WHEN 'C3' THEN 'BD_ADMIN_INFRA.TAGS.MP_C3_STRING'
                    WHEN 'C4' THEN 'BD_ADMIN_INFRA.TAGS.MP_C4_STRING'
                END;
            BEGIN
                EXECUTE IMMEDIATE 'ALTER TABLE ' || :P_TABLE
                    || ' MODIFY COLUMN ' || :P_COL
                    || ' SET MASKING POLICY ' || v_conf_policy
                    || ' USING (' || :P_COL || ')';
                v_res := v_res || '[conf_masking:' || v_conf_policy || '] ';
            EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
                -- NUMBER, DATE, etc. : tag pose, masking ignore
                v_res := v_res || '[conf_masking_skipped:' || v_col_type || '] ';
            END;
        END IF;
    END IF;

    RETURN 'TAGGED COLUMN ' || :P_TABLE || '.' || :P_COL
        || ' (type=' || v_col_type || ') -> ' || TRIM(v_res);
EXCEPTION
    WHEN OTHER THEN RETURN 'TAG_COL_ERR [' || SQLSTATE || ']: ' || SQLERRM;
END;
$$;


/* -- SP_PROTECT_TABLE_DCP ----------------------------------------
   Applique la Row Access Policy DCP sur une table entiere.
   Resultat : 0 lignes pour tout utilisateur sans RF_DCP_AUTHORIZED.
   A appeler sur les tables contenant des donnees personnelles.

   Exemple :
     CALL SP_PROTECT_TABLE_DCP(
         'BD_BRZ_C1.SH_DRC_OE_QEO.TB_OE_POINT_PCE',
         'META_LOAD_TS'
     );
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_PROTECT_TABLE_DCP(
    P_TABLE   VARCHAR,
    P_COL_REF VARCHAR  -- Colonne de reference pour la RAP
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
BEGIN
    EXECUTE IMMEDIATE 'ALTER TABLE '||:P_TABLE
        ||' ADD ROW ACCESS POLICY BD_ADMIN_INFRA.TAGS.RAP_DCP ON ('||:P_COL_REF||')';
    EXECUTE IMMEDIATE 'ALTER TABLE '||:P_TABLE
        ||' SET TAG BD_ADMIN_INFRA.TAGS.DCP = ''sensible''';
    RETURN 'RAP DCP appliquee : '||:P_TABLE;
EXCEPTION WHEN OTHER THEN RETURN 'RAP_WARN ['||SQLSTATE||']: '||SQLERRM;
END;
$$;
