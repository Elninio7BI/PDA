/* =================================================================
   SP_OBJECTS.sql - Creation des objets structurels
   SP_CREATE_DATABASE    -> Database + tag
   SP_CREATE_WH_WITH_RM  -> Warehouse + double Resource Monitor
   SP_CREATE_TABLE       -> Schema + Table META_* + 3 vues + grants + tag
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_DATABASE(VARCHAR,VARCHAR,VARCHAR,NUMBER,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_WH_WITH_RM(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,NUMBER,NUMBER,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_TABLE(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);

/* -- SP_CREATE_DATABASE ----------------------------------------
   Cree BD_{DBTYPE}_{ENV}, supprime PUBLIC, applique les tags.
   Une seule database par couche/env (partagee entre tous les domaines).
   ROLE REQUIS : RD_*_SYSADMIN
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_DATABASE(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_ENV VARCHAR,
    P_QUOTA_DB NUMBER DEFAULT 100, P_NOTIFY_USERS VARCHAR DEFAULT NULL
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n   VARIANT; v_db VARCHAR; v_wh VARCHAR; v_rm VARCHAR; v_sys VARCHAR;
    v_cnt NUMBER;  v_t  TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,'X','X',:P_ENV) INTO v_n;
    v_db  := v_n:DB::VARCHAR;      v_wh := v_n:WH_DB::VARCHAR;
    v_rm  := v_n:RM_DB::VARCHAR;   v_sys := v_n:RD_ACC_SYSADMIN::VARCHAR;

    EXECUTE IMMEDIATE 'USE ROLE '||v_sys;
    EXECUTE IMMEDIATE 'CREATE DATABASE IF NOT EXISTS '||v_db||'
        DATA_RETENTION_TIME_IN_DAYS = 1
        COMMENT = ''Couche '||:P_DBTYPE||' env '||:P_ENV||' - tous domaines''';
    EXECUTE IMMEDIATE 'USE DATABASE '||v_db;
    EXECUTE IMMEDIATE 'DROP SCHEMA IF EXISTS PUBLIC';

    -- Tag de la database
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_OBJECT(v_db,'DATABASE',:P_DBTYPE,:P_SHTYPE,NULL,:P_ENV);

    -- Resource Monitor niveau database (ACCOUNTADMIN obligatoire)
    LET v_notify VARCHAR := CASE WHEN :P_NOTIFY_USERS IS NOT NULL
        THEN 'NOTIFY_USERS = ('||:P_NOTIFY_USERS||')' ELSE '' END;
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'CREATE OR REPLACE RESOURCE MONITOR '||v_rm||'
        WITH CREDIT_QUOTA='||:P_QUOTA_DB||' FREQUENCY=MONTHLY START_TIMESTAMP=IMMEDIATELY '||v_notify||'
        TRIGGERS ON 75 PERCENT DO NOTIFY ON 90 PERCENT DO SUSPEND ON 100 PERCENT DO SUSPEND_IMMEDIATE';
    EXECUTE IMMEDIATE 'ALTER WAREHOUSE '||v_wh||' SET RESOURCE_MONITOR='||v_rm;

    -- Registre META
    SELECT COUNT(*) INTO v_cnt FROM BD_ADMIN_INFRA.META.TB_DATABASES WHERE DB_NAME=v_db;
    IF (v_cnt=0) THEN
        INSERT INTO BD_ADMIN_INFRA.META.TB_DATABASES(DB_NAME,DBTYPE,ENV)
        VALUES(v_db,:P_DBTYPE,:P_ENV);
    END IF;

    v_r := 'OK: '||v_db||' + RM '||v_rm;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_DATABASE','SUCCESS',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_DATABASE','ERROR',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;

/* -- SP_CREATE_WH_WITH_RM --------------------------------------
   Cree le warehouse applicatif + DEUX Resource Monitors :
   - RM_*_PROD : quota eleve, pour les environnements P*
   - RM_*_HP   : quota bas,   pour les environnements C* et H*
   Le bon monitor est assigne automatiquement selon l'env.
   ROLE REQUIS : RD_DB_*_SYSADMIN (CREATE WAREHOUSE)
                 + ACCOUNTADMIN interne (Resource Monitor)
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_WH_WITH_RM(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP VARCHAR, P_ENV VARCHAR, P_WH_SIZE VARCHAR DEFAULT 'XS',
    P_QUOTA_PROD NUMBER DEFAULT 200, P_QUOTA_HP NUMBER DEFAULT 50,
    P_NOTIFY_USERS VARCHAR DEFAULT NULL
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n    VARIANT;
    v_wh   VARCHAR; v_rm_prod VARCHAR; v_rm_hp VARCHAR;
    v_sys  VARCHAR; v_is_prod BOOLEAN;
    v_notify VARCHAR;
    v_cnt  NUMBER;
    v_t    TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,NULL,:P_WH_SIZE) INTO v_n;
    v_wh      := v_n:WH_APP::VARCHAR;
    v_rm_prod := v_n:RM_PROD::VARCHAR;
    v_rm_hp   := v_n:RM_HP::VARCHAR;
    v_sys     := v_n:RD_BD_SYSADMIN::VARCHAR;
    v_is_prod := (LEFT(LOWER(:P_ENV),1)='p');

    EXECUTE IMMEDIATE 'USE ROLE '||v_sys;
    EXECUTE IMMEDIATE 'CREATE WAREHOUSE IF NOT EXISTS '||v_wh||'
        WAREHOUSE_SIZE='''||:P_WH_SIZE||''' AUTO_SUSPEND=60 AUTO_RESUME=TRUE INITIALLY_SUSPENDED=TRUE
        STATEMENT_TIMEOUT_IN_SECONDS=3600 STATEMENT_QUEUED_TIMEOUT_IN_SECONDS=3600
        COMMENT=''WH '||:P_DBTYPE||'_'||:P_SHTYPE||'_'||COALESCE(:P_APP,'X')||' '||:P_ENV||'''';

    -- Tag du warehouse
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_OBJECT(v_wh,'WAREHOUSE',:P_DBTYPE,:P_SHTYPE,:P_APP,:P_ENV);

    -- Deux Resource Monitors (ACCOUNTADMIN exclusif)
    v_notify := CASE WHEN :P_NOTIFY_USERS IS NOT NULL
                THEN 'NOTIFY_USERS = ('||:P_NOTIFY_USERS||')' ELSE '' END;
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    FOR v_rm IN (SELECT r,q FROM TABLE(FLATTEN(ARRAY_CONSTRUCT(
        OBJECT_CONSTRUCT('n',v_rm_prod,'q',:P_QUOTA_PROD),
        OBJECT_CONSTRUCT('n',v_rm_hp,  'q',:P_QUOTA_HP)
    )))) DO
        LET v_name VARCHAR := v_rm.VALUE:n::VARCHAR;
        LET v_quota NUMBER  := v_rm.VALUE:q::NUMBER;
        EXECUTE IMMEDIATE 'CREATE OR REPLACE RESOURCE MONITOR '||v_name||'
            WITH CREDIT_QUOTA='||v_quota||' FREQUENCY=MONTHLY START_TIMESTAMP=IMMEDIATELY '||v_notify||'
            TRIGGERS ON 75 PERCENT DO NOTIFY ON 90 PERCENT DO SUSPEND ON 100 PERCENT DO SUSPEND_IMMEDIATE';
    END FOR;
    -- Assigner le bon monitor
    LET v_actif VARCHAR := CASE WHEN v_is_prod THEN v_rm_prod ELSE v_rm_hp END;
    EXECUTE IMMEDIATE 'ALTER WAREHOUSE '||v_wh||' SET RESOURCE_MONITOR='||v_actif;

    -- Registre META
    SELECT COUNT(*) INTO v_cnt FROM BD_ADMIN_INFRA.META.TB_WAREHOUSES WHERE WH_NAME=v_wh;
    IF (v_cnt=0) THEN
        INSERT INTO BD_ADMIN_INFRA.META.TB_WAREHOUSES(WH_NAME,DBTYPE,SHTYPE,APP,ENV,WH_SIZE,IS_PROD,RM_ACTIF,RM_PROD,RM_HP)
        VALUES(v_wh,:P_DBTYPE,:P_SHTYPE,:P_APP,:P_ENV,:P_WH_SIZE,v_is_prod,v_actif,v_rm_prod,v_rm_hp);
    END IF;

    v_r := 'OK: '||v_wh||' + RM_PROD '||v_rm_prod||' + RM_HP '||v_rm_hp||' (actif:'||v_actif||')';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_WH_WITH_RM','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_WH_WITH_RM','ERROR',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;

/* -- SP_CREATE_TABLE -------------------------------------------
   Cree le schema (MANAGED ACCESS) + la table avec colonnes META_*
   + les 3 vues standard + les grants exhaustifs + les tags.
   ROLE REQUIS : RS_*_OWNER (ou RF_*_ADMIN)
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_TABLE(
    P_DBTYPE   VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP      VARCHAR, P_ENV    VARCHAR,
    P_TBL_NAME VARCHAR, P_DDL    VARCHAR,   -- colonnes metier uniquement
    P_WH_SIZE  VARCHAR DEFAULT 'XS'
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_n    VARIANT;
    v_db   VARCHAR; v_sch  VARCHAR; v_tbl  VARCHAR;
    v_vl   VARCHAR; v_vs   VARCHAR; v_vp   VARCHAR;
    v_rdsh_own VARCHAR; v_ra_own VARCHAR; v_ra_rw VARCHAR; v_ra_ro VARCHAR;
    v_wh   VARCHAR;  v_db_sec VARCHAR;
    v_cnt  NUMBER;
    v_t    TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,:P_TBL_NAME,:P_WH_SIZE) INTO v_n;
    v_db     := v_n:DB::VARCHAR;           v_sch    := v_n:FULL_SCHEMA::VARCHAR;
    v_tbl    := v_n:FULL_TABLE::VARCHAR;   v_wh     := v_n:WH_APP::VARCHAR;
    v_vl     := v_n:VL::VARCHAR;           v_vs     := v_n:VS::VARCHAR;    v_vp := v_n:VP::VARCHAR;
    v_rdsh_own := v_n:RF_SH_ADMIN::VARCHAR;     v_ra_own := v_n:RA_OWNER::VARCHAR;
    v_ra_rw  := v_n:RA_RW::VARCHAR;        v_ra_ro  := v_n:RA_RO::VARCHAR;
    v_db_sec := v_n:RD_BD_SECADMIN::VARCHAR;

    -- RS_OWNER cree les objets
    EXECUTE IMMEDIATE 'USE ROLE '||v_rdsh_own;
    EXECUTE IMMEDIATE 'USE WAREHOUSE '||v_wh;

    -- Schema
    EXECUTE IMMEDIATE 'CREATE SCHEMA IF NOT EXISTS '||v_sch||' WITH MANAGED ACCESS
        COMMENT = ''Schema '||:P_SHTYPE||'_'||:P_OFFRE||COALESCE('_'||:P_APP,'')||' '||:P_DBTYPE||' '||:P_ENV||'''';

    -- Tag du schema
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_OBJECT(v_sch,'SCHEMA',:P_DBTYPE,:P_SHTYPE,:P_APP,:P_ENV);

    -- Table avec colonnes metier + colonnes techniques META_* standard GRDF
    EXECUTE IMMEDIATE '
        CREATE TABLE IF NOT EXISTS '||v_tbl||' (
            '||:P_DDL||',
            META_LOAD_TS       TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP() COMMENT ''Horodatage chargement UTC'',
            META_UPDATE_TS     TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP() COMMENT ''Derniere mise a jour'',
            META_SRC_FILE      VARCHAR(1000)  COMMENT ''Fichier source ou topic Kafka'',
            META_SRC_ROW       NUMBER         COMMENT ''Numero de ligne dans le fichier source'',
            META_BATCH_ID      VARCHAR(100)   COMMENT ''Identifiant de lot'',
            META_PIPELINE_NAME VARCHAR(200)   COMMENT ''Pipeline dbt ou process ayant charge la ligne'',
            META_IS_DELETED    BOOLEAN DEFAULT FALSE COMMENT ''Soft-delete''
        )
        DATA_RETENTION_TIME_IN_DAYS = 1
        CHANGE_TRACKING = TRUE
        COMMENT = ''Table '||:P_OFFRE||'_'||:P_TBL_NAME||' - Couche '||:P_DBTYPE||'''';

    -- Tag de la table
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_OBJECT(v_tbl,'TABLE',:P_DBTYPE,:P_SHTYPE,:P_APP,:P_ENV);

    -- Vue classique (usage interne, filtre soft-delete)
    EXECUTE IMMEDIATE 'CREATE OR REPLACE VIEW '||v_vl||'
        COMMENT = ''Vue interne '||:P_TBL_NAME||'''
        AS SELECT * FROM '||v_tbl||' WHERE META_IS_DELETED = FALSE';

    -- Vue securisee (partage externe, cache les colonnes techniques)
    EXECUTE IMMEDIATE 'CREATE OR REPLACE SECURE VIEW '||v_vs||'
        COMMENT = ''Vue securisee partage '||:P_TBL_NAME||'''
        AS SELECT * EXCLUDE (META_SRC_FILE, META_SRC_ROW, META_PIPELINE_NAME)
        FROM '||v_tbl||' WHERE META_IS_DELETED = FALSE';

    -- Vue materialisee (performance requetes analytiques frequentes)
    EXECUTE IMMEDIATE 'CREATE OR REPLACE MATERIALIZED VIEW '||v_vp||'
        COMMENT = ''Vue materialisee performance '||:P_TBL_NAME||'''
        AS SELECT * FROM '||v_tbl||' WHERE META_IS_DELETED = FALSE';

    -- Grants exhaustifs (12 types) via RD_DB_SECADMIN
    EXECUTE IMMEDIATE 'USE ROLE '||v_db_sec;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_GRANT_SCHEMA_FULL(v_db, v_sch, v_ra_own);
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_GRANT_SCHEMA_RW(v_db, v_sch, v_ra_rw);
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_GRANT_SCHEMA_RO(v_db, v_sch, v_ra_ro);

    -- Registre META schema
    SELECT COUNT(*) INTO v_cnt FROM BD_ADMIN_INFRA.META.TB_SCHEMAS WHERE FULL_SCHEMA=v_sch;
    IF (v_cnt=0) THEN
        INSERT INTO BD_ADMIN_INFRA.META.TB_SCHEMAS(FULL_SCHEMA,DB_NAME,SCHEMA_NAME,DBTYPE,SHTYPE,OFFRE,APP,ENV)
        VALUES(v_sch,v_db,v_n:SCHEMA::VARCHAR,:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV);
    END IF;

    v_r := 'OK: '||v_tbl||' + VL/VS/VP + Tags + Grants (12 types)';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_TABLE','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'OBJECT','COMPLETE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_CREATE_TABLE','ERROR',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'OBJECT','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())); RAISE;
END;
$$;
