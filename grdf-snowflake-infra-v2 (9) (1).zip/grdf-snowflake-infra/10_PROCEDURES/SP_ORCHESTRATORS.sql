/* =================================================================
   SP_ORCHESTRATORS.sql - Points d'entree pour les equipes

   SP_DEPLOY_DATABASE  -> Tier 1 : DB + RD_* + RD_DB_* (admin GRDF)
   SP_DEPLOY_SCHEMA    -> Tier 2 : WH + RA_* + RF_* + RS_* (equipe domaine)
   SP_DEPLOY_TABLE     -> Tier 3 : Table + vues (equipe projet)

   Dans 90% des cas, les equipes n'utilisent que SP_DEPLOY_TABLE.
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_TABLE(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);

-- Supprimer les anciennes signatures pour eviter l'erreur ambiguous overloading
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_DATABASE(VARCHAR,VARCHAR,VARCHAR,VARCHAR,NUMBER,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_SCHEMA(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,NUMBER,NUMBER,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_FULL(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,NUMBER,NUMBER,NUMBER,VARCHAR,VARCHAR);

/* -- SP_DEPLOY_DATABASE ----------------------------------------
   Tier 1 - Execute par l'architecte GRDF (admin Snowflake).
   Deploie la database + les roles de delegation.
   A executer UNE SEULE FOIS par couche/env.

   Apres cet appel : donner RD_DB_*_SYSADMIN aux equipes domaines.
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DEPLOY_DATABASE(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_ENV VARCHAR, P_USER VARCHAR,
    P_QUOTA_DB     NUMBER  DEFAULT 100,
    P_NOTIFY_USERS VARCHAR DEFAULT NULL,
    P_ACCOUNT_CODE VARCHAR DEFAULT 'DFHPRD'
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DEPLOY_DATABASE','INFO',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','START','Tier 1 : Database + RD_* + RD_DB_*',NULL,NULL);

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_DOMAIN_ROLES(:P_DBTYPE,:P_SHTYPE,:P_ENV,:P_USER,:P_ACCOUNT_CODE);
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_DATABASE(:P_DBTYPE,:P_SHTYPE,:P_ENV,:P_QUOTA_DB,:P_NOTIFY_USERS);
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_DB_ROLES(:P_DBTYPE,:P_SHTYPE,:P_ENV,:P_USER);

    v_r := 'DONE Tier 1 - BD_'||:P_DBTYPE||'_'||:P_ENV||' ['||DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())||' ms]'||
           ' - Donner RD_DB_'||:P_DBTYPE||'_'||:P_ENV||'_SYSADMIN aux equipes domaines.';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DEPLOY_DATABASE','SUCCESS',:P_DBTYPE,:P_SHTYPE,NULL,NULL,:P_ENV,'DATABASE','DONE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN RAISE;
END;
$$;

/* -- SP_DEPLOY_SCHEMA ------------------------------------------
   Tier 2 - Execute par l'equipe domaine (avec RD_DB_*_SYSADMIN).
   Deploie le WH applicatif + double RM + roles app + roles schema.
   Ajoute les profils extra via P_EXTRA_ROLES.

   P_EXTRA_ROLES : liste separee par virgule, format : PROFIL:ACCES
                  ex: 'DEV:RW,MOA:RO,ETL:RW,BI:RO'

   Apres cet appel : donner RS_*_OWNER a l'equipe projet.
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DEPLOY_SCHEMA(
    P_DBTYPE VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP VARCHAR, P_ENV VARCHAR, P_USER VARCHAR,
    P_WH_SIZE      VARCHAR DEFAULT 'XS',
    P_QUOTA_PROD   NUMBER  DEFAULT 200,
    P_QUOTA_HP     NUMBER  DEFAULT 50,
    P_NOTIFY_USERS VARCHAR DEFAULT NULL,
    P_EXTRA_ROLES  VARCHAR DEFAULT NULL,
    P_ACCOUNT_CODE VARCHAR DEFAULT 'DFHPRD'
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_t          TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_extra      ARRAY;
    v_i          INTEGER;
    v_pair       VARCHAR;
    v_profil     VARCHAR;
    v_acces      VARCHAR;
    -- Toutes les variables declarees ici pour eviter l'erreur d'inference de type
    v_n          VARIANT;
    v_db_sec     VARCHAR;
    v_db         VARCHAR;
    v_wh_app     VARCHAR;
    v_ra_own     VARCHAR;
    v_ra_rw      VARCHAR;
    v_ra_ro      VARCHAR;
    v_rf_adm     VARCHAR;
    v_rf_moe     VARCHAR;
    v_rf_ana     VARCHAR;
    v_rdacc_acc  VARCHAR;
    v_ra_ro_name  VARCHAR;
    v_ra_rw_name  VARCHAR;
    v_ra_own_name VARCHAR;
    v_dom_adm     VARCHAR;
    v_dom_moe     VARCHAR;
    v_dom_ana     VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DEPLOY_SCHEMA','INFO',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','START','Tier 2 : WH + RA_* + RF_* + RS_*',NULL,NULL);

    -- Warehouse + double Resource Monitor
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_WH_WITH_RM(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,:P_WH_SIZE,:P_QUOTA_PROD,:P_QUOTA_HP,:P_NOTIFY_USERS);

    -- Grants database -> roles RA_*/RF_*
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,NULL,'XS',:P_ACCOUNT_CODE) INTO v_n;
    v_db_sec     := v_n:RD_BD_SECADMIN::VARCHAR;
    v_db         := v_n:DB::VARCHAR;
    v_wh_app     := v_n:WH_APP::VARCHAR;
    v_ra_own     := v_n:RA_OWNER::VARCHAR;
    v_ra_rw      := v_n:RA_RW::VARCHAR;
    v_ra_ro      := v_n:RA_RO::VARCHAR;
    v_rf_adm     := v_n:RF_SH_ADMIN::VARCHAR;
    v_rf_moe     := v_n:RF_SH_MOE::VARCHAR;
    v_rf_ana     := v_n:RF_SH_ANALYST::VARCHAR;
    v_rdacc_acc  := v_n:RD_ACC_ACCADMIN::VARCHAR;

    -- Roles RA_*/RF_* + profil TASK
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_APP_ROLES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,:P_USER);

    -- Synchroniser les RF_DOM_* avec les nouveaux RA_SH_* crees
    v_ra_ro_name  := v_n:RA_RO::VARCHAR;
    v_ra_rw_name  := v_n:RA_RW::VARCHAR;
    v_ra_own_name := v_n:RA_OWNER::VARCHAR;
    v_dom_adm     := v_n:RF_DOM_ADMIN::VARCHAR;
    v_dom_moe     := v_n:RF_DOM_MOE::VARCHAR;
    v_dom_ana     := v_n:RF_DOM_ANALYST::VARCHAR;

    BEGIN
        EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
        -- ANALYST : acces RO
        EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_ro_name ||' TO ROLE '||v_dom_ana;
        -- MOE : acces RW (herite aussi de ANA via hierarchie)
        EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_rw_name ||' TO ROLE '||v_dom_moe;
        -- ADMIN : acces OWNER
        EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_own_name||' TO ROLE '||v_dom_adm;
    EXCEPTION WHEN OTHER THEN NULL;
    END;

    -- Grants DB + WH vers roles fonctionnels
    EXECUTE IMMEDIATE 'USE ROLE '||v_db_sec;
    EXECUTE IMMEDIATE 'GRANT USAGE ON DATABASE '||v_db||' TO ROLE '||v_ra_own;
    EXECUTE IMMEDIATE 'GRANT USAGE ON DATABASE '||v_db||' TO ROLE '||v_ra_rw;
    EXECUTE IMMEDIATE 'GRANT USAGE ON DATABASE '||v_db||' TO ROLE '||v_ra_ro;
    EXECUTE IMMEDIATE 'GRANT CREATE SCHEMA ON DATABASE '||v_db||' TO ROLE '||v_ra_own;
    EXECUTE IMMEDIATE 'GRANT ROLE '||v_ra_ro||' TO ROLE '||v_rdacc_acc;
    EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_app||' TO ROLE '||v_rf_adm;
    EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_app||' TO ROLE '||v_rf_moe;
    EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE '||v_wh_app||' TO ROLE '||v_rf_ana;

    -- Roles RS_* (admin schema - verrou Tier 2 -> Tier 3)
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_SCHEMA_ROLES(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,:P_USER);

    -- Profils extra (DEV, MOA, ETL, BI...)
    IF (:P_EXTRA_ROLES IS NOT NULL AND TRIM(:P_EXTRA_ROLES)!='') THEN
        v_extra := STRTOK_TO_ARRAY(:P_EXTRA_ROLES, ',');
        v_i := 0;
        WHILE (v_i < ARRAY_SIZE(v_extra)) DO
            v_pair   := TRIM(v_extra[v_i]::VARCHAR);
            v_profil := TRIM(SPLIT_PART(v_pair,':',1));
            v_acces  := TRIM(SPLIT_PART(v_pair,':',2));
            IF (v_profil!='' AND v_acces!='') THEN
                CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_ADD_ROLE(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,v_profil,v_acces,NULL,:P_WH_SIZE);
            END IF;
            v_i := v_i + 1;
        END WHILE;
    END IF;

    v_r := 'DONE Tier 2 - SH_'||:P_SHTYPE||'_'||:P_OFFRE||COALESCE('_'||:P_APP,'')||
           ' ['||DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())||' ms]'||
           ' - Donner RS_'||:P_DBTYPE||'_'||:P_SHTYPE||'_'||:P_OFFRE||COALESCE('_'||:P_APP,'')||'_'||:P_ENV||'_OWNER a l''equipe projet.';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DEPLOY_SCHEMA','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'SCHEMA','DONE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN RAISE;
END;
$$;

/* -- SP_DEPLOY_TABLE -------------------------------------------
   Tier 3 - Execute par l'equipe projet (avec RS_*_OWNER).
   C'est la procedure du quotidien pour les equipes autonomes.
   Cree : schema (si absent) + table + 3 vues + grants + tags.

   P_DDL : colonnes metier uniquement (les META_* sont ajoutees auto)
   Exemple :
     CALL SP_DEPLOY_TABLE('BRZ','DRC','OE','QEO','C1',
       'POINT_PCE',
       'PCE_ID NUMBER, STATUT VARCHAR(50), DATE_RELEVE DATE'
     );
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DEPLOY_TABLE(
    P_DBTYPE   VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP      VARCHAR, P_ENV    VARCHAR,
    P_TBL_NAME VARCHAR, P_DDL    VARCHAR,
    P_WH_SIZE  VARCHAR DEFAULT 'XS'
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_TABLE(
        :P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,:P_TBL_NAME,:P_DDL,:P_WH_SIZE);

    v_r := 'DONE Tier 3 - TB_'||:P_OFFRE||'_'||:P_TBL_NAME||' ['||DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())||' ms]';
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DEPLOY_TABLE','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'OBJECT','DONE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN RAISE;
END;
$$;

/* -- SP_DEPLOY_FULL --------------------------------------------
   Deploiement complet Tier 1+2+3 en un seul appel.
   Utile pour les premiers deploiements ou les environnements de test.
   En production, preferer les 3 appels separes pour le controle.
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_DEPLOY_FULL(
    P_DBTYPE   VARCHAR, P_SHTYPE VARCHAR, P_OFFRE VARCHAR,
    P_APP      VARCHAR, P_ENV    VARCHAR,
    P_TBL_NAME VARCHAR, P_DDL    VARCHAR,
    P_USER     VARCHAR,
    P_WH_SIZE      VARCHAR DEFAULT 'XS',
    P_QUOTA_DB     NUMBER  DEFAULT 100,
    P_QUOTA_PROD   NUMBER  DEFAULT 200,
    P_QUOTA_HP     NUMBER  DEFAULT 50,
    P_NOTIFY_USERS VARCHAR DEFAULT NULL,
    P_EXTRA_ROLES  VARCHAR DEFAULT NULL,
    P_ACCOUNT_CODE VARCHAR DEFAULT 'DFHPRD'
)
RETURNS VARCHAR LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r VARCHAR;
BEGIN
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DEPLOY_FULL','INFO',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'ACCOUNT','START',
        '=== DEPLOY FULL '||:P_DBTYPE||'_'||:P_SHTYPE||'_'||:P_OFFRE||'_'||COALESCE(:P_APP,'X')||'_'||:P_ENV||' ===',NULL,NULL);

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_DATABASE(:P_DBTYPE,:P_SHTYPE,:P_ENV,:P_USER,:P_QUOTA_DB,:P_NOTIFY_USERS,:P_ACCOUNT_CODE);
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_SCHEMA(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,:P_USER,:P_WH_SIZE,:P_QUOTA_PROD,:P_QUOTA_HP,:P_NOTIFY_USERS,:P_EXTRA_ROLES,:P_ACCOUNT_CODE);
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_TABLE(:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,:P_TBL_NAME,:P_DDL,:P_WH_SIZE);

    v_r := 'DEPLOY FULL OK ['||DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP())||' ms] - '
        ||:P_DBTYPE||'_'||:P_SHTYPE||'_'||:P_OFFRE||'_'||COALESCE(:P_APP,'X')||'_'||:P_ENV;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_DEPLOY_FULL','SUCCESS',:P_DBTYPE,:P_SHTYPE,:P_OFFRE,:P_APP,:P_ENV,'ACCOUNT','DONE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN RAISE;
END;
$$;
