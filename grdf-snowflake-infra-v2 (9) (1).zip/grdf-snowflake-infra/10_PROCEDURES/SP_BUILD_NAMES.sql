/* =================================================================
   SP_BUILD_NAMES - Source de verite unique du nommage GRDF

   HIERARCHIE DES ROLES :
     RD_ACC_{CODE}_{ROLE}              ACCOUNT  - 1 jeu par compte, sans env
         RD_BD_{DBTYPE}_{ENV}_{ROLE}   DATABASE - 1 jeu par database/env
             RA_{DB}_SH_{...}_{ENV}_{ROLE}  SCHEMA - acces donnees (technique)
                     RF_{DB}_SH_{...}_{ENV}_{ROLE}   profil schema specifique IDA
             RF_{DB}_DOM_{SH}_{ENV}_{ROLE}         profil domaine tous schemas

   NOMENCLATURE :
     RD_ACC_  = Role Delegation ACCOUNT    (sans env, 1 par compte)
     RD_BD_   = Role Delegation BASE DONNEES (avec env, 1 par database)
     RA_{DB}_SH_ = Role Acces SCHEMA donnees  (jamais donne aux humains)
     RF_{DB}_SH_ = Role Fonctionnel SCHEMA    (specifique a un IDA)
     RF_{DB}_DOM_ = Role Fonctionnel DOMAINE (transverse tous schemas du domaine)
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- DROP des anciennes surcharges pour eviter l'erreur "ambiguous overloading"
-- Snowflake interdit 2 procedures de meme nom avec des signatures differentes
-- A executer si SP_BUILD_NAMES existait deja avec une signature differente (ex: 7 params)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR);

CREATE OR REPLACE PROCEDURE SP_BUILD_NAMES(
    P_DBTYPE        VARCHAR,
    P_SHTYPE        VARCHAR,
    P_OFFRE         VARCHAR,
    P_APP           VARCHAR,
    P_ENV           VARCHAR,
    P_TBL_NAME      VARCHAR DEFAULT NULL,
    P_WH_SIZE       VARCHAR DEFAULT 'XS',
    P_ACCOUNT_CODE  VARCHAR DEFAULT 'DFHPRD'
)
RETURNS VARIANT LANGUAGE SQL EXECUTE AS CALLER AS
$$
DECLARE
    v_app_sfx    VARCHAR;

    -- Objets structurels
    v_db         VARCHAR; v_wh_db       VARCHAR; v_rm_db      VARCHAR;
    v_schema     VARCHAR; v_full_schema VARCHAR;
    v_wh_app     VARCHAR; v_rm_prod     VARCHAR; v_rm_hp      VARCHAR;

    -- Table et vues
    v_table      VARCHAR; v_full_table  VARCHAR;
    v_vl         VARCHAR; v_vs          VARCHAR; v_vp         VARCHAR;

    -- RD_ACC_* : delegation ACCOUNT (sans env)
    v_rdacc_sys  VARCHAR; v_rdacc_sec   VARCHAR;
    v_rdacc_usr  VARCHAR; v_rdacc_acc   VARCHAR;

    -- RD_BD_* : delegation DATABASE (avec env)
    v_rdbd_sys   VARCHAR; v_rdbd_sec    VARCHAR;
    v_rdbd_usr   VARCHAR; v_rdbd_acc    VARCHAR;

    -- RA_SH_* : acces donnees schema (technique, jamais donne aux humains)
    v_ra_own     VARCHAR; v_ra_rw       VARCHAR; v_ra_ro      VARCHAR;

    -- RF_SH_* : profils schema specifiques a un IDA
    v_rfsh_adm   VARCHAR; v_rfsh_moe    VARCHAR;
    v_rfsh_ana   VARCHAR; v_rfsh_tsk    VARCHAR;

    -- RF_DOM_* : profils domaine transverses (tous schemas DBTYPE/SHTYPE/ENV)
    -- Crees automatiquement par SP_DEPLOY_DATABASE
    v_rfdom_adm  VARCHAR; v_rfdom_moe   VARCHAR; v_rfdom_ana  VARCHAR;

    -- Compte de service
    v_sa         VARCHAR;
BEGIN
    v_app_sfx := CASE WHEN :P_APP IS NULL OR TRIM(:P_APP) = ''
                      THEN '' ELSE '_' || TRIM(:P_APP) END;

    -- Objets structurels
    v_db          := 'BD_'  || :P_DBTYPE || '_' || :P_ENV;
    v_wh_db       := 'WH_BD_' || :P_DBTYPE || '_' || :P_ENV || '_' || :P_WH_SIZE;
    v_rm_db       := 'RM_BD_' || :P_DBTYPE || '_' || :P_ENV;
    v_schema      := 'SH_'  || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx;
    v_full_schema := v_db   || '.' || v_schema;
    v_wh_app      := 'WH_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE
                            || v_app_sfx  || '_' || :P_ENV || '_' || :P_WH_SIZE;
    v_rm_prod     := 'RM_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE
                            || v_app_sfx  || '_' || :P_ENV || '_PROD';
    v_rm_hp       := 'RM_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE
                            || v_app_sfx  || '_' || :P_ENV || '_HP';

    -- Table et vues
    IF (:P_TBL_NAME IS NOT NULL AND TRIM(:P_TBL_NAME) != '') THEN
        v_table      := 'TB_' || :P_OFFRE || '_' || :P_TBL_NAME;
        v_full_table := v_full_schema || '.' || v_table;
        v_vl         := v_full_schema || '.VL_' || :P_OFFRE || '_' || :P_TBL_NAME;
        v_vs         := v_full_schema || '.VS_' || :P_OFFRE || '_' || :P_TBL_NAME;
        v_vp         := v_full_schema || '.VP_' || :P_OFFRE || '_' || :P_TBL_NAME;
    END IF;

    -- RD_ACC_* : 1 jeu par compte Snowflake, SANS env
    -- Partages entre tous les domaines du meme compte
    v_rdacc_sys  := 'RD_ACC_' || :P_ACCOUNT_CODE || '_SYSADMIN';
    v_rdacc_sec  := 'RD_ACC_' || :P_ACCOUNT_CODE || '_SECADMIN';
    v_rdacc_usr  := 'RD_ACC_' || :P_ACCOUNT_CODE || '_USRADMIN';
    v_rdacc_acc  := 'RD_ACC_' || :P_ACCOUNT_CODE || '_ACCADMIN';

    -- RD_BD_* : 1 jeu par database/env
    -- BD = abrege de BASE DE DONNEES (coherent avec le prefixe BD_ des databases)
    v_rdbd_sys   := 'RD_BD_' || :P_DBTYPE || '_' || :P_ENV || '_SYSADMIN';
    v_rdbd_sec   := 'RD_BD_' || :P_DBTYPE || '_' || :P_ENV || '_SECADMIN';
    v_rdbd_usr   := 'RD_BD_' || :P_DBTYPE || '_' || :P_ENV || '_USRADMIN';
    v_rdbd_acc   := 'RD_BD_' || :P_DBTYPE || '_' || :P_ENV || '_ACCADMIN';

    -- RA_{DBTYPE}_SH_* : acces technique aux donnees d'un schema specifique
    -- Format : RA_{DBTYPE}_SH_{SHTYPE}_{OFFRE}[_{APP}]_{ENV}_{NIVEAU}
    -- Lien direct avec le schema SH_{SHTYPE}_{OFFRE}[_{APP}] dans BD_{DBTYPE}_{ENV}
    -- Jamais donne directement aux humains - herite par RF_*_SH_*
    v_ra_own     := 'RA_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx
                          || '_' || :P_ENV || '_OWNER';
    v_ra_rw      := 'RA_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx
                          || '_' || :P_ENV || '_RW';
    v_ra_ro      := 'RA_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx
                          || '_' || :P_ENV || '_RO';

    -- RF_{DBTYPE}_SH_* : profils fonctionnels specifiques a un schema/IDA
    -- Format : RF_{DBTYPE}_SH_{SHTYPE}_{OFFRE}[_{APP}]_{ENV}_{PROFIL}
    -- Miroir du schema SH_{SHTYPE}_{OFFRE}[_{APP}] - lien direct et lisible
    v_rfsh_adm   := 'RF_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx
                          || '_' || :P_ENV || '_ADMIN';
    v_rfsh_moe   := 'RF_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx
                          || '_' || :P_ENV || '_MOE';
    v_rfsh_ana   := 'RF_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx
                          || '_' || :P_ENV || '_ANALYST';
    v_rfsh_tsk   := 'RF_' || :P_DBTYPE || '_SH_' || :P_SHTYPE || '_' || :P_OFFRE || v_app_sfx
                          || '_' || :P_ENV || '_TASK';

    -- RF_{DBTYPE}_DOM_* : profils domaine transverses
    -- Format : RF_{DBTYPE}_DOM_{SHTYPE}_{ENV}_{PROFIL}
    -- Pas d'APP ni d'OFFRE : couvre TOUS les schemas du domaine
    -- Ex: RF_BRZ_DOM_DRC_C1_ANALYST = acces RO a tous les schemas BRZ/DRC/C1
    -- Crees automatiquement a chaque SP_DEPLOY_DATABASE (3 profils)
    v_rfdom_adm  := 'RF_' || :P_DBTYPE || '_DOM_' || :P_SHTYPE || '_' || :P_ENV || '_ADMIN';
    v_rfdom_moe  := 'RF_' || :P_DBTYPE || '_DOM_' || :P_SHTYPE || '_' || :P_ENV || '_MOE';
    v_rfdom_ana  := 'RF_' || :P_DBTYPE || '_DOM_' || :P_SHTYPE || '_' || :P_ENV || '_ANALYST';

    -- SA_DEPLOY : compte de service pipeline
    v_sa := 'SA_DEPLOY_' || :P_ACCOUNT_CODE || '_' || :P_DBTYPE
                         || '_' || :P_SHTYPE || '_' || :P_ENV;

    RETURN OBJECT_CONSTRUCT(
        -- Objets structurels
        'DB',              v_db,
        'WH_DB',           v_wh_db,
        'RM_DB',           v_rm_db,
        'SCHEMA',          v_schema,
        'FULL_SCHEMA',     v_full_schema,
        'WH_APP',          v_wh_app,
        'RM_PROD',         v_rm_prod,
        'RM_HP',           v_rm_hp,
        -- Table et vues
        'TABLE',           COALESCE(v_table,      ''),
        'FULL_TABLE',      COALESCE(v_full_table, ''),
        'VL',              COALESCE(v_vl,         ''),
        'VS',              COALESCE(v_vs,         ''),
        'VP',              COALESCE(v_vp,         ''),
        -- Delegation ACCOUNT (sans env)
        'RD_ACC_SYSADMIN', v_rdacc_sys,
        'RD_ACC_SECADMIN', v_rdacc_sec,
        'RD_ACC_USRADMIN', v_rdacc_usr,
        'RD_ACC_ACCADMIN', v_rdacc_acc,
        -- Delegation DATABASE
        'RD_BD_SYSADMIN',  v_rdbd_sys,
        'RD_BD_SECADMIN',  v_rdbd_sec,
        'RD_BD_USRADMIN',  v_rdbd_usr,
        'RD_BD_ACCADMIN',  v_rdbd_acc,
        -- Acces donnees schema
        'RA_OWNER',        v_ra_own,
        'RA_RW',           v_ra_rw,
        'RA_RO',           v_ra_ro,
        -- Profils schema (specifiques IDA)
        'RF_SH_ADMIN',     v_rfsh_adm,
        'RF_SH_MOE',       v_rfsh_moe,
        'RF_SH_ANALYST',   v_rfsh_ana,
        'RF_SH_TASK',      v_rfsh_tsk,
        -- Profils domaine (transverses - crees auto par SP_DEPLOY_DATABASE)
        'RF_DOM_ADMIN',    v_rfdom_adm,
        'RF_DOM_MOE',      v_rfdom_moe,
        'RF_DOM_ANALYST',  v_rfdom_ana,
        -- Compte de service
        'SA_DEPLOY',       v_sa,
        'HAS_APP',         (v_app_sfx != '')
    );
END;
$$;

-- Tests rapides (sans rien creer)
-- CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES('BRZ','DRC','OE','QEO','C1');
-- CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES('BRZ','DRC','OE','QEO','C1',NULL,'XS','DFHPRD');
-- CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES('DRC','SLV','OM',NULL,'C1');
