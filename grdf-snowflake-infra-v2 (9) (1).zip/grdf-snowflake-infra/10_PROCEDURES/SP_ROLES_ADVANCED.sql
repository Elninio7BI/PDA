/* =================================================================
   SP_ROLES_ADVANCED.sql - Roles fonctionnels transverses

   SP_CREATE_CROSS_DOMAIN_ROLE -> Role agregeant des RA_* selon
                                  3 filtres combinables
   SP_SYNC_CROSS_DOMAIN_ROLE   -> Rattraper les nouveaux schemas
   SP_REVOKE_ROLE              -> Revoquer un acces (trace)
   SP_LIST_ROLE_GRANTS         -> Diagnostic des acces d'un role

   --- LES 3 DIMENSIONS DE FILTRAGE -----------------------------

   Tous les RA_* suivent la convention :
   RA_{DBTYPE}_{SHTYPE}[_{IDA}]_{ACCES}_{ENV}

   Dimension 1 - P_COUCHES  : filtre sur DBTYPE (segment 1)
     Valeurs : 'BRZ', 'GLD', 'DRC', 'SLV'...
     NULL    : toutes les couches

   Dimension 2 - P_DOMAINES : filtre sur SHTYPE (segment 2)
     Valeurs : 'DRC', 'DTI', 'OSD', 'SLV', 'GLD'...
     NULL    : tous les domaines

   Dimension 3 - P_IDAS     : filtre sur IDA (segment 3, optionnel)
     Valeurs : 'QEO', 'BPO', 'PSP', 'PRESTA'...
     NULL    : toutes les IDA (y compris les schemas sans IDA)

   --- EXEMPLES RAPIDES ------------------------------------------

   Bronze DRC toutes IDA :
     COUCHES=['BRZ']  DOMAINES=['DRC']  IDAS=NULL
     -> RA_BRZ_DRC_QEO_RO_C1, RA_BRZ_DRC_PSP_RO_C1, RA_BRZ_DRC_INT_RO_C1...

   Bronze+Gold DRC IDA specifiques :
     COUCHES=['BRZ','GLD']  DOMAINES=['DRC']  IDAS=['QEO','BPO']
     -> RA_BRZ_DRC_QEO_RO_C1 + RA_GLD_DRC_BPO_RO_C1 seulement

   Silver stream DRC :
     COUCHES=['DRC']  DOMAINES=['SLV']  IDAS=NULL
     -> RA_DRC_SLV_OM_PRESTA_RO_C1, RA_DRC_SLV_OM_RO_C1...

   Tout le compte en lecture :
     COUCHES=NULL  DOMAINES=NULL  IDAS=NULL
     -> Tous les RA_*_RO_C1 sans exception
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA SH_DEPLOY;

-- Supprimer les anciennes signatures (evite ambiguous overloading)
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_CROSS_DOMAIN_ROLE(VARCHAR,VARCHAR,ARRAY,ARRAY,ARRAY,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_SYNC_CROSS_DOMAIN_ROLE(VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_REVOKE_ROLE(VARCHAR,VARCHAR,VARCHAR,VARCHAR);
DROP PROCEDURE IF EXISTS BD_ADMIN_INFRA.SH_DEPLOY.SP_LIST_ROLE_GRANTS(VARCHAR);


/* -- SP_CREATE_CROSS_DOMAIN_ROLE -------------------------------

   PARAMETRES :
     P_PROFIL   VARCHAR   Nom du profil -> cree RF_GLOBAL_{PROFIL}_{ENV}
     P_ENV      VARCHAR   Environnement (C1, H1, P1...)
     P_COUCHES  ARRAY     Couches (DBTYPE) - NULL = toutes
     P_DOMAINES ARRAY     Domaines (SHTYPE) - NULL = tous
     P_IDAS     ARRAY     Codes IDA - NULL = tous (incl. schemas sans IDA)
     P_ACCES    VARCHAR   RO | RW | OWNER (defaut RO)
     P_USERS    VARCHAR   Utilisateurs separes par virgule (optionnel)
     P_WH       VARCHAR   Warehouse a accorder au role (optionnel)
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_CREATE_CROSS_DOMAIN_ROLE(
    P_PROFIL   VARCHAR,
    P_ENV      VARCHAR,
    P_COUCHES  ARRAY   DEFAULT NULL,
    P_DOMAINES ARRAY   DEFAULT NULL,
    P_IDAS     ARRAY   DEFAULT NULL,
    P_ACCES    VARCHAR DEFAULT 'RO',
    P_USERS    VARCHAR DEFAULT NULL,
    P_WH       VARCHAR DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_new_role  VARCHAR;
    v_pattern   VARCHAR;
    v_query_id  VARCHAR;
    v_granted   NUMBER  := 0;
    v_skipped   NUMBER  := 0;
    v_names_log VARCHAR := '';
    v_user_arr  ARRAY;
    v_i         INTEGER;
    v_t         TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    IF (:P_ACCES NOT IN ('RO','RW','OWNER')) THEN
        RETURN 'ERREUR: P_ACCES doit etre RO, RW ou OWNER';
    END IF;

    -- Nom du role transverse
    v_new_role := 'RF_GLOBAL_' || UPPER(:P_PROFIL) || '_' || :P_ENV;

    -- Creer le role
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE '
        CREATE ROLE IF NOT EXISTS ' || v_new_role || '
        COMMENT = ''Role transverse ' || UPPER(:P_PROFIL) || ' | '
            || UPPER(:P_ACCES) || ' | '
            || 'couches:' || COALESCE(ARRAY_TO_STRING(:P_COUCHES, '+'), 'ALL') || ' | '
            || 'domaines:' || COALESCE(ARRAY_TO_STRING(:P_DOMAINES, '+'), 'ALL') || ' | '
            || 'IDA:' || COALESCE(ARRAY_TO_STRING(:P_IDAS, '+'), 'ALL') || ' | '
            || 'env:' || :P_ENV || '''';

    EXECUTE IMMEDIATE 'GRANT ROLE ' || v_new_role || ' TO ROLE SYSADMIN';

    -- Parcourir tous les RA correspondant au pattern acces+env
    v_pattern := 'RA_%_SH_%_' || UPPER(:P_ACCES) || '_' || :P_ENV;
    SHOW ROLES LIKE :v_pattern;
    SELECT LAST_QUERY_ID() INTO v_query_id;

    LET c_roles CURSOR FOR (
        SELECT "name" AS RNAME FROM TABLE(RESULT_SCAN(:v_query_id))
    );
    OPEN c_roles;
    FOR rec IN c_roles DO
        LET v_rname VARCHAR := rec.RNAME;

        -- -- Extraire DBTYPE, SHTYPE, IDA depuis le nom ---------
        -- Supprime "RA_" au debut et "_{ACCES}_{ENV}" a la fin
        LET v_core   VARCHAR := SUBSTR(v_rname, 4);
        LET v_suffix VARCHAR := '_' || UPPER(:P_ACCES) || '_' || :P_ENV;
        LET v_inner  VARCHAR := SUBSTR(v_core, 1, LEN(v_core) - LEN(v_suffix));

        -- Segments : BRZ_DRC_QEO -> [BRZ, DRC, QEO]
        LET v_seg1 VARCHAR := UPPER(TRIM(SPLIT_PART(v_inner, '_', 1))); -- DBTYPE
        LET v_seg2 VARCHAR := UPPER(TRIM(SPLIT_PART(v_inner, '_', 2))); -- SHTYPE
        LET v_seg3 VARCHAR := UPPER(TRIM(SPLIT_PART(v_inner, '_', 3))); -- IDA (peut etre '')

        -- -- Filtre COUCHE ---------------------------------------
        LET v_ok_couche BOOLEAN := TRUE;
        IF (:P_COUCHES IS NOT NULL AND ARRAY_SIZE(:P_COUCHES) > 0) THEN
            v_ok_couche := FALSE;
            LET v_c INTEGER := 0;
            WHILE (v_c < ARRAY_SIZE(:P_COUCHES) AND NOT v_ok_couche) DO
                IF (v_seg1 = UPPER(TRIM(:P_COUCHES[v_c]::VARCHAR))) THEN
                    v_ok_couche := TRUE;
                END IF;
                v_c := v_c + 1;
            END WHILE;
        END IF;

        -- -- Filtre DOMAINE --------------------------------------
        LET v_ok_dom BOOLEAN := TRUE;
        IF (:P_DOMAINES IS NOT NULL AND ARRAY_SIZE(:P_DOMAINES) > 0) THEN
            v_ok_dom := FALSE;
            LET v_d INTEGER := 0;
            WHILE (v_d < ARRAY_SIZE(:P_DOMAINES) AND NOT v_ok_dom) DO
                IF (v_seg2 = UPPER(TRIM(:P_DOMAINES[v_d]::VARCHAR))) THEN
                    v_ok_dom := TRUE;
                END IF;
                v_d := v_d + 1;
            END WHILE;
        END IF;

        -- -- Filtre IDA ------------------------------------------
        -- Si filtre IDA fourni ET le role a un IDA -> verifier
        -- Si filtre IDA fourni ET le role n'a pas d'IDA -> inclure quand meme
        --   (schema generique = tout le monde peut y acceder)
        LET v_ok_ida BOOLEAN := TRUE;
        IF (:P_IDAS IS NOT NULL AND ARRAY_SIZE(:P_IDAS) > 0 AND v_seg3 != '') THEN
            v_ok_ida := FALSE;
            LET v_a INTEGER := 0;
            WHILE (v_a < ARRAY_SIZE(:P_IDAS) AND NOT v_ok_ida) DO
                IF (v_seg3 = UPPER(TRIM(:P_IDAS[v_a]::VARCHAR))) THEN
                    v_ok_ida := TRUE;
                END IF;
                v_a := v_a + 1;
            END WHILE;
        END IF;

        -- -- GRANT si les 3 filtres passent ---------------------
        IF (v_ok_couche AND v_ok_dom AND v_ok_ida) THEN
            BEGIN
                EXECUTE IMMEDIATE 'GRANT ROLE ' || v_rname || ' TO ROLE ' || v_new_role;
                v_granted   := v_granted + 1;
                v_names_log := v_names_log || '  ' || v_rname || CHR(10);
            EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
                v_skipped := v_skipped + 1;
            END;
        END IF;

    END FOR;
    CLOSE c_roles;

    -- Warehouse optionnel
    IF (:P_WH IS NOT NULL AND TRIM(:P_WH) != '') THEN
        EXECUTE IMMEDIATE 'GRANT USAGE ON WAREHOUSE ' || :P_WH || ' TO ROLE ' || v_new_role;
    END IF;

    -- Attribution aux utilisateurs
    IF (:P_USERS IS NOT NULL AND TRIM(:P_USERS) != '') THEN
        v_user_arr := STRTOK_TO_ARRAY(:P_USERS, ',');
        v_i := 0;
        WHILE (v_i < ARRAY_SIZE(v_user_arr)) DO
            LET v_u VARCHAR := TRIM(v_user_arr[v_i]::VARCHAR);
            IF (v_u != '') THEN
                EXECUTE IMMEDIATE 'GRANT ROLE ' || v_new_role || ' TO USER ' || v_u;
            END IF;
            v_i := v_i + 1;
        END WHILE;
    END IF;

    -- Registre META
    LET v_cnt NUMBER := 0;
    SELECT COUNT(*) INTO v_cnt FROM BD_ADMIN_INFRA.META.TB_ROLES WHERE ROLE_NAME = v_new_role;
    IF (v_cnt = 0) THEN
        INSERT INTO BD_ADMIN_INFRA.META.TB_ROLES (ROLE_NAME, FAMILLE, PROFIL, ENV)
        VALUES (v_new_role, 'RF_GLOBAL', UPPER(:P_PROFIL), :P_ENV);
    END IF;

    v_r :=
        v_new_role || ' cree - ' || v_granted || ' role(s) accorde(s)' ||
        CASE WHEN v_skipped > 0 THEN ' / ' || v_skipped || ' ignore(s)' ELSE '' END ||
        CHR(10) || 'Filtres : ' ||
        'couches=' || COALESCE(ARRAY_TO_STRING(:P_COUCHES,'+'),'TOUTES') ||
        ' | domaines=' || COALESCE(ARRAY_TO_STRING(:P_DOMAINES,'+'),'TOUS') ||
        ' | IDA=' || COALESCE(ARRAY_TO_STRING(:P_IDAS,'+'),'TOUS') ||
        CHR(10) || 'Roles accordes :' || CHR(10) || v_names_log;

    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT(
        'SP_CREATE_CROSS_DOMAIN_ROLE','SUCCESS',NULL,NULL,NULL,NULL,:P_ENV,
        'ACCOUNT','COMPLETE',v_r,
        DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),
        DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;

EXCEPTION WHEN OTHER THEN
    v_sqlstate := SQLSTATE;
    v_sqlerrm  := SQLERRM;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT(
        'SP_CREATE_CROSS_DOMAIN_ROLE','ERROR',NULL,NULL,NULL,NULL,:P_ENV,
        'ACCOUNT','EXCEPTION','ERR ['||v_sqlstate||']: '||v_sqlerrm,
        DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),
        DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RAISE;
END;
$$;


/* -- SP_SYNC_CROSS_DOMAIN_ROLE ---------------------------------
   A appeler apres chaque SP_DEPLOY_SCHEMA pour que les nouveaux
   roles RA_* soient automatiquement accordes aux roles transverses
   concernes.

   P_ROLE_PATTERN  Filtre sur les roles transverses
                   ex: 'RF_GLOBAL_%_C1'  -> tous les globaux C1
                   ex: 'RF_BRZ_DOM_DRC_C1_ANALYST'  -> un seul
   P_NEW_RA        Nom exact du nouveau RA a accorder
                   ex: 'RA_BRZ_DRC_PSR_RO_C1'
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_SYNC_CROSS_DOMAIN_ROLE(
    P_ROLE_PATTERN VARCHAR,
    P_NEW_RA       VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_query_id VARCHAR;
    v_synced   NUMBER := 0;
BEGIN
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    SHOW ROLES LIKE :P_ROLE_PATTERN;
    SELECT LAST_QUERY_ID() INTO v_query_id;

    LET c_roles CURSOR FOR (
        SELECT "name" AS RNAME
        FROM TABLE(RESULT_SCAN(:v_query_id))
        WHERE "name" LIKE 'RF_GLOBAL_%'
    );
    OPEN c_roles;
    FOR rec IN c_roles DO
        BEGIN
            EXECUTE IMMEDIATE 'GRANT ROLE ' || :P_NEW_RA || ' TO ROLE ' || rec.RNAME;
            v_synced := v_synced + 1;
        EXCEPTION WHEN OTHER THEN NULL;
        END;
    END FOR;
    CLOSE c_roles;

    RETURN 'SYNC: ' || :P_NEW_RA || ' -> ' || v_synced || ' role(s) transverse(s) mis a jour';
END;
$$;


/* -- SP_REVOKE_ROLE ------------------------------------------- */
CREATE OR REPLACE PROCEDURE SP_REVOKE_ROLE(
    P_ROLE      VARCHAR,
    P_FROM_TYPE VARCHAR,  -- USER | ROLE
    P_FROM_NAME VARCHAR,
    P_ENV       VARCHAR DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_t TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    v_r          VARCHAR;
    v_sqlstate   VARCHAR;
    v_sqlerrm    VARCHAR;
BEGIN
    IF (UPPER(:P_FROM_TYPE) NOT IN ('USER','ROLE')) THEN
        RETURN 'ERREUR: P_FROM_TYPE doit etre USER ou ROLE';
    END IF;
    EXECUTE IMMEDIATE 'USE ROLE ACCOUNTADMIN';
    EXECUTE IMMEDIATE 'REVOKE ROLE ' || :P_ROLE
        || ' FROM ' || UPPER(:P_FROM_TYPE) || ' ' || :P_FROM_NAME;
    v_r := 'REVOKE ' || :P_ROLE || ' FROM ' || UPPER(:P_FROM_TYPE) || ' ' || :P_FROM_NAME;
    CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LOG_EVENT('SP_REVOKE_ROLE','SUCCESS',NULL,NULL,NULL,NULL,COALESCE(:P_ENV,'?'),'ACCOUNT','REVOKE',v_r,DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()),DATEDIFF('millisecond',v_t,CURRENT_TIMESTAMP()));
    RETURN v_r;
EXCEPTION WHEN OTHER THEN RETURN 'ERR [' || SQLSTATE || ']: ' || SQLERRM;
END;
$$;


/* -- SP_LIST_ROLE_GRANTS ---------------------------------------
   Diagnostic : liste les roles RA_* accordes a un role transverse.
   
   Utilise SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES (vrai table)
   au lieu de SHOW GRANTS + RESULT_SCAN car :
     - SHOW ne supporte pas IDENTIFIER() avec une variable
     - SHOW ne peut pas etre utilise dans EXECUTE IMMEDIATE
     - ORDER BY interdit dans RETURN TABLE() en Snowflake Scripting
   
   Note : ACCOUNT_USAGE a un delai de ~45 min. Pour un resultat
   temps reel, utiliser directement :
     SHOW GRANTS TO ROLE <nom_du_role>;
------------------------------------------------------------------ */
CREATE OR REPLACE PROCEDURE SP_LIST_ROLE_GRANTS(P_ROLE VARCHAR)
RETURNS TABLE (ROLE_ACCORDE VARCHAR, DBTYPE VARCHAR, SHTYPE VARCHAR, IDA VARCHAR, NIVEAU VARCHAR, ENV VARCHAR)
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    -- RETURN TABLE(SELECT ...) inline n'est PAS supporte en Snowflake Scripting.
    -- Il faut obligatoirement affecter le SELECT a un RESULTSET,
    -- puis passer ce RESULTSET a RETURN TABLE().
    v_result RESULTSET;
BEGIN
    v_result := (
        SELECT
            gr.NAME                                                                AS ROLE_ACCORDE,
            TRIM(SPLIT_PART(REGEXP_REPLACE(gr.NAME,'^RA_(.+)_(RO|RW|OWNER)_[A-Z][0-9]+$','\1'),'_',1)) AS DBTYPE,
            TRIM(SPLIT_PART(REGEXP_REPLACE(gr.NAME,'^RA_(.+)_(RO|RW|OWNER)_[A-Z][0-9]+$','\1'),'_',2)) AS SHTYPE,
            TRIM(SPLIT_PART(REGEXP_REPLACE(gr.NAME,'^RA_(.+)_(RO|RW|OWNER)_[A-Z][0-9]+$','\1'),'_',3)) AS IDA,
            REGEXP_SUBSTR(gr.NAME,'RO|RW|OWNER')                                  AS NIVEAU,
            REGEXP_SUBSTR(gr.NAME,'[A-Z][0-9]+$')                                 AS ENV
        FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES gr
        WHERE gr.DELETED_ON IS NULL
          AND gr.GRANTEE_NAME = UPPER(:P_ROLE)
          AND gr.GRANTED_ON   = 'ROLE'
          AND gr.PRIVILEGE    = 'USAGE'
          AND gr.NAME LIKE 'RA_%_SH_%'
    );
    RETURN TABLE(v_result);
END;
$$;


/* ================================================================
   EXEMPLES COMPLETS D'UTILISATION

-- Data Engineer - Bronze DRC en ecriture, toutes IDA ---------

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_CROSS_DOMAIN_ROLE(
    'DATA_ENGINEER', 'C1',
    ARRAY_CONSTRUCT('BRZ'),    -- couche Bronze uniquement
    ARRAY_CONSTRUCT('DRC'),    -- domaine DRC
    NULL,                      -- toutes les IDA DRC
    'RW',                      -- lecture + ecriture
    'sa_etl_drc_c1',
    'WH_BRZ_XS_C1'
);
-- Cree : RF_GLOBAL_DATA_ENGINEER_C1
-- Accorde : RA_BRZ_DRC_QEO_RW_C1, RA_BRZ_DRC_PSP_RW_C1, RA_BRZ_DRC_INT_RW_C1...


-- Data Scientist - Bronze + Gold DRC, lecture seule ---------

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_CROSS_DOMAIN_ROLE(
    'DATA_SCIENTIST', 'C1',
    ARRAY_CONSTRUCT('BRZ', 'GLD'),  -- Bronze ET Gold
    ARRAY_CONSTRUCT('DRC'),
    NULL,                           -- toutes IDA
    'RO',
    'jean.martin,marie.durand'
);


-- Referent metier - Gold DRC, IDA BPO seulement -------------

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_CROSS_DOMAIN_ROLE(
    'REFERENT_BPO', 'C1',
    ARRAY_CONSTRUCT('GLD'),
    ARRAY_CONSTRUCT('DRC'),
    ARRAY_CONSTRUCT('BPO'),   -- IDA specifique
    'RO',
    'christelle.dupont'
);


-- Analyste multi-IDA - DRC BPO + QEO, Bronze + Gold ---------

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_CROSS_DOMAIN_ROLE(
    'ANALYSTE_OFFRE', 'C1',
    ARRAY_CONSTRUCT('BRZ', 'GLD'),
    ARRAY_CONSTRUCT('DRC'),
    ARRAY_CONSTRUCT('QEO', 'BPO'),  -- deux IDA
    'RO',
    'analyste.offre.grdf'
);


-- Silver stream DRC - DBTYPE=DRC, SHTYPE=SLV ----------------

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_CROSS_DOMAIN_ROLE(
    'SILVER_DRC', 'C1',
    ARRAY_CONSTRUCT('DRC'),   -- DBTYPE = stream DRC
    ARRAY_CONSTRUCT('SLV'),   -- SHTYPE = couche Silver dans DRC
    NULL,
    'RO',
    'silver.analyst'
);


-- Auditeur global - tout le compte ----------------------------

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_CREATE_CROSS_DOMAIN_ROLE(
    'AUDITEUR_GLOBAL', 'C1',
    NULL, NULL, NULL,   -- aucun filtre = tout
    'RO'
);


-- Apres SP_DEPLOY_SCHEMA (nouveau schema DRC PSR) -------------
-- Synchroniser les roles globaux pour qu'ils voient le nouveau schema

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_SYNC_CROSS_DOMAIN_ROLE(
    'RF_GLOBAL_%_C1',           -- tous les roles globaux C1
    'RA_BRZ_DRC_PSR_RO_C1'     -- nouveau RA a ajouter
);


-- Diagnostic - que peut voir RF_BRZ_DOM_DRC_C1_ANALYST ? ----

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_LIST_ROLE_GRANTS('RF_BRZ_DOM_DRC_C1_ANALYST');
-- ROLE_ACCORDE           DBTYPE  SHTYPE  IDA   NIVEAU  ENV
-- RA_BRZ_DRC_QEO_RO_C1  BRZ     DRC     QEO   RO      C1
-- RA_BRZ_DRC_PSP_RO_C1  BRZ     DRC     PSP   RO      C1
-- RA_GLD_DRC_BPO_RO_C1  GLD     DRC     BPO   RO      C1


-- Revoquer un acces --------------------------------------------

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_REVOKE_ROLE(
    'RF_BRZ_DOM_DRC_C1_ANALYST', 'USER', 'jean.martin', 'C1'
);
================================================================ */
