/* =================================================================
   02_tags_securite.sql
   A executer UNE SEULE FOIS avec ACCOUNTADMIN apres 01_.
   Cree les 6 tags GRDF et les politiques de securite associees.

   PRINCIPE : Poser le tag sur un objet = activer la protection.
   Le tag dcp='sensible' sur une colonne -> masquage automatique.
   Le tag confidentialite='C4' -> donnees visibles RSSI uniquement.
================================================================= */

USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;

CREATE SCHEMA IF NOT EXISTS TAGS WITH MANAGED ACCESS
    COMMENT = 'Tags de classification et securite GRDF';

-- Role administrateur des tags (acces tres restreint)
USE ROLE USERADMIN;
CREATE ROLE IF NOT EXISTS RF_TAGS_ADMIN
    COMMENT = 'Admin des tags et policies de securite - RSSI GRDF uniquement';
GRANT ROLE RF_TAGS_ADMIN TO ROLE SYSADMIN;

-- Roles d'autorisation pour les donnees sensibles
CREATE ROLE IF NOT EXISTS RF_DCP_AUTHORIZED
    COMMENT = 'Acces donnees personnelles (DCP) - Accorde par le DPO';
CREATE ROLE IF NOT EXISTS RF_C3_AUTHORIZED
    COMMENT = 'Acces donnees confidentielles C3 - Accorde par le responsable domaine';
CREATE ROLE IF NOT EXISTS RF_C4_AUTHORIZED
    COMMENT = 'Acces donnees strictement confidentielles C4 - Accorde par le RSSI';

-- Hierarchie : C4 voit tout, C3 voit C3+DCP, DCP voit DCP uniquement
GRANT ROLE RF_DCP_AUTHORIZED TO ROLE RF_C3_AUTHORIZED;
GRANT ROLE RF_C3_AUTHORIZED  TO ROLE RF_C4_AUTHORIZED;
GRANT ROLE RF_C4_AUTHORIZED  TO ROLE RF_TAGS_ADMIN;

USE ROLE SECURITYADMIN;
GRANT ALL PRIVILEGES ON SCHEMA BD_ADMIN_INFRA.TAGS TO ROLE RF_TAGS_ADMIN;
GRANT APPLY TAG ON ACCOUNT TO ROLE RF_TAGS_ADMIN;
-- Lecture publique des tags (pour que les procedures puissent les referencer)
GRANT USAGE ON DATABASE BD_ADMIN_INFRA TO ROLE PUBLIC;
GRANT USAGE ON SCHEMA BD_ADMIN_INFRA.TAGS TO ROLE PUBLIC;

USE ROLE RF_TAGS_ADMIN;
USE SCHEMA BD_ADMIN_INFRA.TAGS;

/* -- 6 TAGS STANDARDS GRDF -------------------------------------- */

-- Classification contextuelle (qui/ou/quand)
CREATE OR REPLACE TAG application
    COMMENT = 'Code application GRDF proprietaire de l''objet (ex: brz_qeo, drc_bpo)';

CREATE OR REPLACE TAG environnement
    ALLOWED_VALUES 'c1','c2','c3','c4','c5','c6','c7','c8','c9',
                   'h1','h2','h3','h4','h5','h6','h7','h8','h9',
                   'p1','p2','p3'
    COMMENT = 'Environnement GRDF (c=continu, h=homologation, p=production)';

CREATE OR REPLACE TAG domaine
    COMMENT = 'Domaine metier GRDF (ex: drc, dti, osd, rh, economique)';

CREATE OR REPLACE TAG couche
    ALLOWED_VALUES 'BRZ','SLV','GLD','REF','GLOBAL'
    COMMENT = 'Couche data : BRZ bronze / SLV silver / GLD gold / REF referentiel';

-- Classification securite (quoi proteger)
CREATE OR REPLACE TAG confidentialite
    ALLOWED_VALUES 'C1','C2','C3','C4'
    COMMENT = 'C1=Public C2=Interne C3=Confidentiel C4=Strictement Confidentiel';

CREATE OR REPLACE TAG dcp
    ALLOWED_VALUES 'normal','sensible'
    COMMENT = 'DCP RGPD : normal=pas de donnee perso / sensible=donnee personnelle';

/* -- MASKING POLICIES - Tag dcp='sensible' --------------------- */
-- Activees automatiquement sur toute colonne taguee dcp='sensible'

CREATE OR REPLACE MASKING POLICY MP_DCP_STRING AS (v STRING) RETURNS STRING ->
    CASE WHEN IS_ROLE_IN_SESSION('RF_DCP_AUTHORIZED')
          OR IS_ROLE_IN_SESSION('RF_TAGS_ADMIN')
          OR IS_ROLE_IN_SESSION('ACCOUNTADMIN') THEN v
         ELSE '***DCP_SENSIBLE***'
    END COMMENT = 'Masquage DCP texte';

CREATE OR REPLACE MASKING POLICY MP_DCP_NUMBER AS (v NUMBER) RETURNS NUMBER ->
    CASE WHEN IS_ROLE_IN_SESSION('RF_DCP_AUTHORIZED')
          OR IS_ROLE_IN_SESSION('RF_TAGS_ADMIN')
          OR IS_ROLE_IN_SESSION('ACCOUNTADMIN') THEN v
         ELSE -9999999
    END COMMENT = 'Masquage DCP numerique';

CREATE OR REPLACE MASKING POLICY MP_DCP_DATE AS (v DATE) RETURNS DATE ->
    CASE WHEN IS_ROLE_IN_SESSION('RF_DCP_AUTHORIZED')
          OR IS_ROLE_IN_SESSION('RF_TAGS_ADMIN')
          OR IS_ROLE_IN_SESSION('ACCOUNTADMIN') THEN v
         ELSE DATE('1900-01-01')
    END COMMENT = 'Masquage DCP date';

CREATE OR REPLACE MASKING POLICY MP_DCP_TIMESTAMP AS (v TIMESTAMP_NTZ) RETURNS TIMESTAMP_NTZ ->
    CASE WHEN IS_ROLE_IN_SESSION('RF_DCP_AUTHORIZED')
          OR IS_ROLE_IN_SESSION('RF_TAGS_ADMIN')
          OR IS_ROLE_IN_SESSION('ACCOUNTADMIN') THEN v
         ELSE TO_TIMESTAMP_NTZ('1900-01-01 00:00:00')
    END COMMENT = 'Masquage DCP timestamp';

/* -- MASKING POLICIES - Confidentialite C3/C4 ----------------- */

CREATE OR REPLACE MASKING POLICY MP_C3_STRING AS (v STRING) RETURNS STRING ->
    CASE WHEN IS_ROLE_IN_SESSION('RF_C3_AUTHORIZED')
          OR IS_ROLE_IN_SESSION('RF_TAGS_ADMIN')
          OR IS_ROLE_IN_SESSION('ACCOUNTADMIN') THEN v
         ELSE '***CONFIDENTIEL_C3***'
    END COMMENT = 'Masquage C3 Confidentiel';

CREATE OR REPLACE MASKING POLICY MP_C4_STRING AS (v STRING) RETURNS STRING ->
    CASE WHEN IS_ROLE_IN_SESSION('RF_C4_AUTHORIZED')
          OR IS_ROLE_IN_SESSION('RF_TAGS_ADMIN')
          OR IS_ROLE_IN_SESSION('ACCOUNTADMIN') THEN v
         ELSE '***SECRET_C4***'
    END COMMENT = 'Masquage C4 Strictement Confidentiel';

/* -- ROW ACCESS POLICY - Tag dcp='sensible' sur une TABLE ------ */
-- Resultat : 0 lignes pour tout utilisateur sans RF_DCP_AUTHORIZED

CREATE OR REPLACE ROW ACCESS POLICY RAP_DCP AS (col STRING) RETURNS BOOLEAN ->
    IS_ROLE_IN_SESSION('RF_DCP_AUTHORIZED')
    OR IS_ROLE_IN_SESSION('RF_TAGS_ADMIN')
    OR IS_ROLE_IN_SESSION('ACCOUNTADMIN')
    COMMENT = 'DCP : bloque toutes les lignes pour les non-autorises';

/* -- NOTE IMPORTANTE : Comment fonctionne la protection DCP -----
   Snowflake ne supporte PAS l'association d'une masking policy
   a un tag par type de donnees (syntaxe ON COLUMN TYPE invalide).

   La protection DCP fonctionne en 2 temps via SP_TAG_COLUMN :

   1. SP_TAG_COLUMN pose le tag dcp='sensible' sur la colonne
      -> Tracabilite : la colonne apparait dans VL_DCP_OBJECTS

   2. SP_TAG_COLUMN applique AUSSI la masking policy appropriee
      selon le type reel de la colonne :
        STRING        -> SET MASKING POLICY MP_DCP_STRING
        NUMBER        -> SET MASKING POLICY MP_DCP_NUMBER
        DATE          -> SET MASKING POLICY MP_DCP_DATE
        TIMESTAMP_NTZ -> SET MASKING POLICY MP_DCP_TIMESTAMP

   TOUJOURS utiliser SP_TAG_COLUMN pour taguer une colonne DCP.
   Ne jamais poser le tag manuellement sans appliquer la policy.

   Exemple :
     CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_COLUMN(
         'BD_BRZ_C1.SH_DRC_OE_QEO.TB_OE_POINT_PCE',
         'EMAIL_CONTACT', 'sensible', 'C3'
     );
--------------------------------------------------------------- */

/* -- VUES DE PILOTAGE ------------------------------------------ */

CREATE OR REPLACE VIEW VL_TAGGED_OBJECTS AS
SELECT OBJECT_DATABASE, OBJECT_SCHEMA, OBJECT_NAME, COLUMN_NAME,
       TAG_NAME, TAG_VALUE
FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES
WHERE TAG_DATABASE = 'BD_ADMIN_INFRA'
ORDER BY OBJECT_DATABASE, TAG_NAME, TAG_VALUE;

CREATE OR REPLACE VIEW VL_DCP_OBJECTS AS
SELECT OBJECT_DATABASE, OBJECT_SCHEMA, OBJECT_NAME, COLUMN_NAME
FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES
WHERE TAG_DATABASE = 'BD_ADMIN_INFRA'
  AND TAG_NAME = 'DCP' AND TAG_VALUE = 'sensible';

CREATE OR REPLACE VIEW VL_CONF_OBJECTS AS
SELECT OBJECT_DATABASE, OBJECT_SCHEMA, OBJECT_NAME, COLUMN_NAME, TAG_VALUE AS NIVEAU
FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES
WHERE TAG_DATABASE = 'BD_ADMIN_INFRA' AND TAG_NAME = 'CONFIDENTIALITE'
ORDER BY TAG_VALUE;
