/* =================================================================
   00_INIT/04_audit_views.sql
   A executer UNE SEULE FOIS apres 03_meta_registry.sql
   
   Cree les vues d'audit des droits et acces.
   Repond aux questions :
     - Qui a acces a quel schema et avec quel niveau ?
     - Quels roles sont accordes a quel utilisateur ?
     - Quels objets sont proteges DCP ?
     - Historique des deploiements par domaine
   
   Ces vues utilisent SNOWFLAKE.ACCOUNT_USAGE - les donnees
   ont un delai de 45 min a 3h selon les tables.
   Pour un etat en temps reel -> utiliser SHOW GRANTS.
================================================================= */
USE ROLE ACCOUNTADMIN;
USE DATABASE BD_ADMIN_INFRA;
USE SCHEMA META;

/* -- VL_AUDIT_USER_ACCESS --------------------------------------
   Qui a acces a quoi ? - Vue agregee par utilisateur et domaine.
   Question DSI : "Lister tous les acces de Jean Dupont"
------------------------------------------------------------------ */
CREATE OR REPLACE VIEW VL_AUDIT_USER_ACCESS AS
SELECT
    gr.GRANTEE_NAME         AS USER_NAME,
    gr.ROLE                 AS ROLE_ACCORDE,
    CASE
        WHEN gr.ROLE LIKE 'RF_%ADMIN%'   THEN 'ADMIN - lecture/ecriture/gestion schema'
        WHEN gr.ROLE LIKE 'RF_%MOE%'     THEN 'MOE - lecture et ecriture donnees'
        WHEN gr.ROLE LIKE 'RF_%ANALYST%' THEN 'ANALYST - lecture seule'
        WHEN gr.ROLE LIKE 'RF_%TASK%'    THEN 'TASK - execution des taches planifiees'
        WHEN gr.ROLE LIKE 'RF_%ETL%'     THEN 'ETL - chargement donnees (ecriture)'
        WHEN gr.ROLE LIKE 'RF_%BI%'      THEN 'BI - lecture pour outils de reporting'
        WHEN gr.ROLE LIKE 'RF_%MOA%'     THEN 'MOA - lecture seule (metier)'
        WHEN gr.ROLE LIKE 'RF_%DEV%'     THEN 'DEV - lecture et ecriture (developpeur)'
        WHEN gr.ROLE LIKE 'RF_GLOBAL%'   THEN 'GLOBAL - acces transverse multi-domaines'
        WHEN gr.ROLE LIKE 'RS_%OWNER%'   THEN 'SCHEMA OWNER - proprietaire du schema'
        WHEN gr.ROLE LIKE 'RS_%ADMIN%'   THEN 'SCHEMA ADMIN - DDL + DML schema'
        WHEN gr.ROLE LIKE 'RS_%TEAM%'    THEN 'SCHEMA TEAM - DML schema'
        WHEN gr.ROLE LIKE 'RD_DB%'       THEN 'DB ADMIN - administration database'
        WHEN gr.ROLE LIKE 'RD_%'         THEN 'DOMAIN ADMIN - administration domaine'
        ELSE 'Autre'
    END                     AS PROFIL_LISIBLE,
    -- Extraire le domaine du nom de role (convention RF_{DBTYPE}_{SHTYPE}_*_{ENV})
    SPLIT_PART(gr.ROLE, '_', 3) AS DOMAINE_ESTIME,
    -- Extraire l'env (dernier segment)
    REGEXP_SUBSTR(gr.ROLE, '[A-Z][0-9]+$') AS ENV,
    gr.CREATED_ON           AS DATE_ACCORD,   -- CREATED_ON dans GRANTS_TO_USERS (pas GRANTED_ON)
    gr.GRANTED_BY           AS ACCORDE_PAR
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_USERS gr
WHERE gr.DELETED_ON IS NULL
  AND gr.ROLE LIKE 'R%_%_%'  -- uniquement les roles framework
ORDER BY gr.GRANTEE_NAME, ENV, DOMAINE_ESTIME;

/* -- VL_AUDIT_ROLE_HIERARCHY -----------------------------------
   Hierarchie complete des roles - qui herite de quoi.
   Question DSI : "Qu'est-ce que RF_BRZ_DRC_QEO_ADMIN_C1 peut faire ?"
------------------------------------------------------------------ */
CREATE OR REPLACE VIEW VL_AUDIT_ROLE_HIERARCHY AS
SELECT
    gr.GRANTEE_NAME         AS ROLE_PARENT,     -- Role qui recoit le grant
    gr.NAME                 AS ROLE_ACCORDE,    -- Role accorde (colonne NAME dans GRANTS_TO_ROLES)
    CASE
        WHEN gr.NAME LIKE 'RA_%OWNER%' THEN 'FULL - propriete des objets'
        WHEN gr.NAME LIKE 'RA_%RW%'    THEN 'RW - lecture + ecriture'
        WHEN gr.NAME LIKE 'RA_%RO%'    THEN 'RO - lecture seule'
        ELSE 'Autre role'
    END                     AS NIVEAU_ACCES,
    gr.CREATED_ON           AS DATE_ACCORD,
    gr.GRANTED_BY           AS ACCORDE_PAR
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES gr
WHERE gr.DELETED_ON IS NULL
  AND gr.GRANTED_ON = 'ROLE'    -- Uniquement les grants de roles (pas tables/schemas)
  AND gr.PRIVILEGE  = 'USAGE'   -- Les grants de roles utilisent USAGE
  AND (gr.GRANTEE_NAME LIKE 'RF_%' OR gr.GRANTEE_NAME LIKE 'RS_%' OR gr.GRANTEE_NAME LIKE 'RD_%' OR gr.GRANTEE_NAME LIKE 'RA_%')
ORDER BY gr.GRANTEE_NAME, NIVEAU_ACCES;

/* -- VL_AUDIT_SCHEMA_ACCESS ------------------------------------
   Qui peut acceder a chaque schema et comment.
   Croisement META.TB_SCHEMAS avec les roles connus.
   Question : "Qui a acces au schema BD_BRZ_C1.SH_DRC_OE_QEO ?"
------------------------------------------------------------------ */
CREATE OR REPLACE VIEW VL_AUDIT_SCHEMA_ACCESS AS
SELECT
    s.FULL_SCHEMA,
    s.DBTYPE,
    s.SHTYPE,
    s.OFFRE,
    s.APP,
    s.ENV,
    -- Roles d'acces calcules depuis la convention de nommage
    'RA_' || s.DBTYPE || '_' || s.SHTYPE || COALESCE('_' || s.APP, '') || '_OWNER_' || s.ENV AS ROLE_FULL,
    'RA_' || s.DBTYPE || '_' || s.SHTYPE || COALESCE('_' || s.APP, '') || '_RW_'    || s.ENV AS ROLE_RW,
    'RA_' || s.DBTYPE || '_' || s.SHTYPE || COALESCE('_' || s.APP, '') || '_RO_'    || s.ENV AS ROLE_RO,
    'RF_' || s.DBTYPE || '_' || s.SHTYPE || COALESCE('_' || s.APP, '') || '_ADMIN_' || s.ENV AS PROFIL_ADMIN,
    'RF_' || s.DBTYPE || '_' || s.SHTYPE || COALESCE('_' || s.APP, '') || '_MOE_'   || s.ENV AS PROFIL_MOE,
    'RF_' || s.DBTYPE || '_' || s.SHTYPE || COALESCE('_' || s.APP, '') || '_ANALYST_' || s.ENV AS PROFIL_ANALYST,
    s.CREATED_AT,
    s.CREATED_BY
FROM BD_ADMIN_INFRA.META.TB_SCHEMAS s
ORDER BY s.ENV, s.DBTYPE, s.SHTYPE, s.APP;

/* -- VL_AUDIT_DCP_COVERAGE -------------------------------------
   Couverture DCP : quelles colonnes sont protegees vs exposees.
   Question RSSI/DPO : "Avons-nous taggue toutes nos donnees personnelles ?"
   Note : utilise ACCOUNT_USAGE.TAG_REFERENCES (delai ~45 min)
------------------------------------------------------------------ */
CREATE OR REPLACE VIEW VL_AUDIT_DCP_COVERAGE AS
SELECT
    tr.OBJECT_DATABASE  AS DATABASE_NAME,
    tr.OBJECT_SCHEMA    AS SCHEMA_NAME,
    tr.OBJECT_NAME      AS TABLE_NAME,
    tr.COLUMN_NAME,
    tr.TAG_NAME,
    tr.TAG_VALUE,
    CASE tr.TAG_NAME
        WHEN 'DCP'             THEN '[CRITIQUE] Donnee personnelle - masquage actif'
        WHEN 'CONFIDENTIALITE' THEN
            CASE tr.TAG_VALUE
                WHEN 'C4' THEN '[CRITIQUE] Strictement Confidentiel - RSSI uniquement'
                WHEN 'C3' THEN '[IMPORTANT] Confidentiel - acces restreint'
                WHEN 'C2' THEN '[WARN] Interne - usage GRDF uniquement'
                WHEN 'C1' THEN '[OK] Public - pas de restriction'
            END
        ELSE '[-] Tag contextuel'
    END AS PROTECTION_STATUT,
    tr.TAG_DATABASE
FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES tr
WHERE tr.TAG_DATABASE = 'BD_ADMIN_INFRA'
  AND tr.TAG_NAME IN ('DCP', 'CONFIDENTIALITE')
  AND tr.OBJECT_DELETED IS NULL
ORDER BY tr.TAG_VALUE DESC, tr.OBJECT_DATABASE, tr.OBJECT_SCHEMA, tr.OBJECT_NAME;

/* -- VL_AUDIT_DEPLOY_HISTORY -----------------------------------
   Historique des deploiements par domaine et periode.
   Question : "Qu'est-ce qui a ete deploye cette semaine ?"
------------------------------------------------------------------ */
CREATE OR REPLACE VIEW VL_AUDIT_DEPLOY_HISTORY AS
SELECT
    DATE_TRUNC('day', LOG_TS) AS JOUR,
    DBTYPE,
    SHTYPE,
    APP,
    ENV,
    PROCEDURE_NAME,
    LOG_LEVEL,
    TIER,
    MESSAGE,
    EXECUTED_BY,
    EXECUTED_ROLE,
    TOTAL_DURATION_MS
FROM BD_ADMIN_INFRA.SH_DEPLOY.TB_DEPLOY_LOG
WHERE LOG_LEVEL IN ('SUCCESS', 'ERROR', 'WARN')
  AND STEP NOT LIKE '%_START%'  -- Exclure les lignes INFO de debut
ORDER BY LOG_TS DESC;

/* -- VL_AUDIT_ORPHAN_ROLES -------------------------------------
   Roles framework qui n'ont AUCUN utilisateur.
   Question : "Y a-t-il des roles inutilises a nettoyer ?"
   Note : utilise ACCOUNT_USAGE (delai ~45 min)
------------------------------------------------------------------ */
CREATE OR REPLACE VIEW VL_AUDIT_ORPHAN_ROLES AS
SELECT
    r.ROLE_NAME,
    r.FAMILLE,
    r.PROFIL,
    r.DBTYPE,
    r.SHTYPE,
    r.ENV,
    r.CREATED_AT,
    'Aucun utilisateur direct - verifier si herite par un role fonctionnel' AS NOTE
FROM BD_ADMIN_INFRA.META.TB_ROLES r
WHERE r.ROLE_NAME NOT IN (
    SELECT ROLE FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_USERS
    WHERE DELETED_ON IS NULL
)
ORDER BY r.CREATED_AT DESC;

/* -- GRANT lecture des vues META/AUDIT -------------------------
   Les administrateurs de domaine peuvent consulter les vues d'audit
------------------------------------------------------------------ */
USE ROLE SECURITYADMIN;
GRANT USAGE ON SCHEMA BD_ADMIN_INFRA.META TO ROLE SYSADMIN;
GRANT SELECT ON ALL VIEWS IN SCHEMA BD_ADMIN_INFRA.META TO ROLE SYSADMIN;
GRANT SELECT ON FUTURE VIEWS IN SCHEMA BD_ADMIN_INFRA.META TO ROLE SYSADMIN;

/* ================================================================
   REQUETES D'AUDIT PRATIQUES

-- "Qui a acces aux donnees DRC ?"
SELECT USER_NAME, ROLE_ACCORDE, PROFIL_LISIBLE, DATE_ACCORD
FROM BD_ADMIN_INFRA.META.VL_AUDIT_USER_ACCESS
WHERE DOMAINE_ESTIME = 'DRC'
ORDER BY USER_NAME;

-- "Quels sont les roles de Jean Dupont ?"
SELECT ROLE_ACCORDE, PROFIL_LISIBLE, ENV, DATE_ACCORD, ACCORDE_PAR
FROM BD_ADMIN_INFRA.META.VL_AUDIT_USER_ACCESS
WHERE USER_NAME = 'JEAN_DUPONT';

-- "Quelles colonnes sont taguees DCP sensible ?"
SELECT DATABASE_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME
FROM BD_ADMIN_INFRA.META.VL_AUDIT_DCP_COVERAGE
WHERE TAG_NAME = 'DCP' AND TAG_VALUE = 'sensible';

-- "Qu'est-ce qui a ete deploye hier ?"
SELECT JOUR, DBTYPE, APP, ENV, PROCEDURE_NAME, MESSAGE, EXECUTED_BY
FROM BD_ADMIN_INFRA.META.VL_AUDIT_DEPLOY_HISTORY
WHERE JOUR = CURRENT_DATE - 1;

-- "Y a-t-il des acces C4 non justifies ?"
SELECT u.USER_NAME, u.ROLE_ACCORDE, u.DATE_ACCORD, u.ACCORDE_PAR
FROM BD_ADMIN_INFRA.META.VL_AUDIT_USER_ACCESS u
WHERE u.ROLE_ACCORDE = 'RF_C4_AUTHORIZED';
================================================================ */
