/* =================================================================
   20_DEPLOY/BRZ_DRC_QEO_C1.sql
   Deploiement : Bronze DRC QEO - Environnement C1

   COPIER CE FICHIER pour chaque nouveau socle :
     cp BRZ_DRC_QEO_C1.sql DRC_SLV_OM_PRESTA_H1.sql
     -> modifier les parametres dans chaque CALL

   VALEURS RECOMMANDEES PAR ENVIRONNEMENT :
     C* dev  : WH=XS  QUOTA_DB=50  QUOTA_PROD=50  QUOTA_HP=25   EXTRA=DEV:RW,MOA:RO,ETL:RW
     H* hml  : WH=S   QUOTA_DB=150 QUOTA_PROD=150 QUOTA_HP=50   EXTRA=MOA:RO,ETL:RW
     P* prod : WH=M   QUOTA_DB=500 QUOTA_PROD=500 QUOTA_HP=100  EXTRA=ETL:RW,BI:RO
================================================================= */

USE SECONDARY ROLES ALL;
USE ROLE ACCOUNTADMIN;


/* -- APERCU : noms qui seront crees (sans rien creer) ---------- */

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_BUILD_NAMES(
    'BRZ',      -- P_DBTYPE
    'DRC',      -- P_SHTYPE
    'OE',       -- P_OFFRE
    'QEO',      -- P_APP    (NULL = schema sans app)
    'C1',       -- P_ENV
    NULL,       -- P_TBL_NAME (optionnel)
    'XS',       -- P_WH_SIZE
    'DFHPRD'    -- P_ACCOUNT_CODE
);


/* -- TIER 1 : Database + roles delegues -----------------------
   Une seule fois par DBTYPE/ENV. Idempotent.
   Cree : BD_BRZ_C1, WH_BD_BRZ_C1_XS, RM_BD_BRZ_C1
          RD_ACC_DFHPRD_*, RD_BD_BRZ_C1_*
          RF_BRZ_DOM_DRC_C1_ADMIN/MOE/ANALYST
------------------------------------------------------------- */

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_DATABASE(
    'BRZ',      -- P_DBTYPE
    'DRC',      -- P_SHTYPE
    'C1',       -- P_ENV
    'FJ6634',   -- P_USER          recoit les roles RD_ACC_* et RD_BD_*
    50,         -- P_QUOTA_DB      credits/mois RM niveau database
    'FJ6634'    -- P_NOTIFY_USERS  alerte quota
);


/* -- TIER 2 : Warehouse applicatif + roles schema -------------
   Une seule fois par schema/IDA. Idempotent.
   Cree : WH_BRZ_SH_DRC_OE_QEO_C1_XS
          RM_BRZ_SH_DRC_OE_QEO_C1_PROD / _HP
          RA_BRZ_SH_DRC_OE_QEO_C1_OWNER/RW/RO
          RF_BRZ_SH_DRC_OE_QEO_C1_ADMIN/MOE/ANALYST/TASK
          RF_BRZ_SH_DRC_OE_QEO_C1_DEV/MOA/ETL
------------------------------------------------------------- */

CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_SCHEMA(
    'BRZ',                      -- P_DBTYPE
    'DRC',                      -- P_SHTYPE
    'OE',                       -- P_OFFRE
    'QEO',                      -- P_APP
    'C1',                       -- P_ENV
    'FJ6634',                   -- P_USER
    'XS',                       -- P_WH_SIZE
    50,                         -- P_QUOTA_PROD   credits/mois env P*
    25,                         -- P_QUOTA_HP     credits/mois env C*/H*
    'FJ6634',                   -- P_NOTIFY_USERS
    'DEV:RW,MOA:RO,ETL:RW'     -- P_EXTRA_ROLES
);


/* -- TIER 3 : Tables et vues ----------------------------------
   A repeter pour chaque table. Idempotent.
   Cree : SH_DRC_OE_QEO (si absent)
          TB_OE_{NOM} + 7 META_* auto
          VL_ / VS_ / VP_
          Grants 12 types d objets + tags
------------------------------------------------------------- */

-- Table 1 : Points de Comptage et d Estimation
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_TABLE(
    'BRZ', 'DRC', 'OE', 'QEO', 'C1',
    'POINT_PCE',                        -- nom fonctionnel -> TB_OE_POINT_PCE
    'PCE_ID           NUMBER     NOT NULL,
     CODE_POSTAL      VARCHAR(10),
     STATUT           VARCHAR(50),
     DATE_RELEVE      DATE,
     CONSOMMATION_KWH NUMBER(18,4)',
    'XS'
);

-- Table 2 : Contrats
CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_DEPLOY_TABLE(
    'BRZ', 'DRC', 'OE', 'QEO', 'C1',
    'CONTRAT',                          -- nom fonctionnel -> TB_OE_CONTRAT
    'CONTRAT_ID  NUMBER  NOT NULL,
     PCE_ID      NUMBER,
     DATE_DEBUT  DATE,
     DATE_FIN    DATE,
     TYPE_CONTRAT VARCHAR(50)',
    'XS'
);

-- Pour ajouter une table : copier un bloc SP_DEPLOY_TABLE
-- changer le nom fonctionnel et le DDL


/* -- SECURITE (si donnees personnelles) -----------------------
   Decommenter apres creation des tables.
------------------------------------------------------------- */

-- Taguer une colonne -> masquage automatique
-- CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_TAG_COLUMN(
--     'BD_BRZ_C1.SH_DRC_OE_QEO.TB_OE_POINT_PCE',
--     'EMAIL', 'sensible', 'C3'
-- );

-- Proteger toute la table -> 0 lignes pour non-autorises
-- CALL BD_ADMIN_INFRA.SH_DEPLOY.SP_PROTECT_TABLE_DCP(
--     'BD_BRZ_C1.SH_DRC_OE_QEO.TB_OE_POINT_PCE', 'META_LOAD_TS'
-- );


/* -- VERIFICATION POST-DEPLOIEMENT --------------------------- */

SELECT LOG_TS, TIER, STEP, LOG_LEVEL, MESSAGE, TOTAL_DURATION_MS
FROM BD_ADMIN_INFRA.SH_DEPLOY.VL_DEPLOY_SUMMARY
WHERE DBTYPE = 'BRZ' AND ENV = 'C1'
ORDER BY LOG_TS DESC LIMIT 30;
